define(["qlik"], function(qlik) {

    return {
        props: {
            itemTitleRef: function(data) {
                return data.actionType;
            },
            items: {
                actionType: {
                    type: "string",
                    component: "dropdown",
                    ref: "actionType",
                    label: "Select an action",
                    options: [
                        { value: "setVariable", label: "Set variable" },
                        { value: "selectInField", label: "Select in field"},
                        { value: "clearField", label: "Clear a field"},
                        { value: "clearAllFields", label: "Clear ALL fields"},
                        { value: "gotoSheet", label: "Go to sheet"},
                        { value: "gotoUrl", label: "Go to URL"}
                    ]
                },
                setVariableName: {
                    type: "string",
                    ref: "setVariableName",
                    label: "Enter variable name",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "setVariable";
                    }
                },
                setVariableValue: {
                    type: "string",
                    ref: "setVariableValue",
                    label: "Enter variable value",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "setVariable";
                    }
                },
                selectInFieldName: {
                    type: "string",
                    ref: "selectInFieldName",
                    label: "Enter field name",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "selectInField";
                    }
                },
                selectInFieldValue: {
                    type: "string",
                    ref: "selectInFieldValue",
                    label: "Enter field value",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "selectInField";
                    }
                },
                clearFieldName: {
                    type: "string",
                    ref: "clearFieldName",
                    label: "Enter field name to clear",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "clearField";
                    }
                },
                gotoSheetOption: {
                    type: "string",
                    ref: "gotoSheetOption",
                    component: "buttongroup",
                    options: [
                        { value: "list", label: "List", tooltip: "Choose the sheet from a list" },
                        { value: "expr", label: "Expr", tooltip: "Define sheet using an expression" }
                    ],
                    defaultValue: "list",
                    show: function(data) {
                        return data.actionType === "gotoSheet";
                    }
                },
                gotoSheetName: {
                    type: "string",
                    ref: "gotoSheetName",
                    label: "Enter sheet name",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "gotoSheet" && data.gotoSheetOption === "expr";
                    }
                },
                gotoSheetId: {
                    type: "string",
                    ref: "gotoSheetId",
                    label: "Select a sheet",
                    component: "dropdown",
                    options: Utilities.getSheetList(),
                    show: function(data) {
                        return data.actionType === "gotoSheet" && data.gotoSheetOption === "list";
                    }
                },
                gotoUrlName: {
                    type: "string",
                    ref: "gotoUrlName",
                    label: "Enter URL",
                    expression: "optional",
                    show: function(data) {
                        return data.actionType === "gotoUrl";
                    }
                }
            }
        },

        functions: {
            //Function to get the sheet id from given name
            getSheetId: function(name) {
                return $scope.sheetList.filter(function(sheet) {
                    return sheet.label === name;
                })[0].value
            },

            //Set a variable action function
            setVariable: function(name, value) {
                switch (typeof value) {
                    case "string":
                        app.variable.setStringValue(name, value);
                        break;
                    case "number":
                        app.variable.setNumValue(name, value);
                        break;
                }
            },

            //Select in field action function
            selectInField: function(name, value, toggle, softLock) {
                var valueArray, range = false;
                toggle = toggle || true;
                softLock = softLock || true;
                
                if (value.indexOf(",") !== -1) {
                    valueArray = value.split(",").map(function(valueItem) {
                        return isNaN(valueItem) ? valueItem : parseInt(valueItem);
                    })
                } else {
                    range = value.indexOf("<") !== -1 || value.indexOf(">") !== -1 ? true : false;
                    valueArray = [isNaN(value) ? value : parseInt(value)]
                }
                if (range) {
                    app.field(name).selectMatch(valueArray[0], toggle);
                } else {
                    app.field(name).selectValues(valueArray, toggle, softLock);
                }
            },

            //Clear field action function
            clearField: function(name) {
                app.field(name).clear();
            },

            //Clear ALL fields action function
            clearAllFields: function() {
                app.clearAll();
            },

            //Function to go to sheet using the sheet id
            gotoSheet: function(sheetId) {
                qlik.navigation.gotoSheet(sheetId);
            },

            //Handle Action function
            onHandleAction: function(actions, workInEditMode) {

                if (qlik.navigation.getMode() === 'edit' && !workInEditMode) return;

                actions.forEach(function(action) {
                    switch (action.actionType) {
                        case "setVariable":
                            setVariable(action.setVariableName, action.setVariableValue);
                            break;
                        case "selectInField":
                            selectInField(action.selectInFieldName, action.selectInFieldValue.replace(/\"/g, ""));
                            break;
                        case "clearField":
                            clearField(action.clearFieldName);
                            break;
                        case "clearAllFields":
                            clearAllFields();
                            break;
                        case "gotoSheet":
                            switch (action.gotoSheetOption) {
                                case "expr":
                                    gotoSheet(getSheetId(action.gotoSheetName));
                                    break;
                                case "list":
                                    gotoSheet(action.gotoSheetId);
                                    break;
                            }
                            break;
                        case "gotoUrl":
                            var urlPrefix = action.gotoUrlName.indexOf("http") > -1 ? "" : "http://";
                            window.open(urlPrefix + action.gotoUrlName);
                            break;
                    }
                })
            }
        }
    }
});