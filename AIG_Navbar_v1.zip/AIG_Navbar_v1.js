﻿define( [
	"qlik", 
	"text!./AIG_Navbar_v1.html", 
	"text!./dialog-template.ng.html", 
	"./Utilities", 
	"./lui-icon-options", 
	"./fa-icon-options",
	"./FileSaver",
	"css!./css/AIG_Navbar.css", 
	"css!./Fonts/fontawesome/css/font-awesome.min.css"
],
	function ( 
		qlik, 
		template, 
		dialogTemplate,
		Utilities, 
		luiIconOptions, 
		faIconOptions,
		FileSaver
	) {

		var app = qlik.currApp(this);

		getIcons = function() {
			return luiIconOptions.map(function(icon) {
				return {value: icon.value, label: icon.label + " LUI"}
			}).concat(faIconOptions.map(function(icon) { 
				return {value: "fa fa-" + icon.id, label: icon.name + " FA"}
			})).sort(function(a,b) {
				if (a.label.toLowerCase() < b.label.toLowerCase()) return -1
				if (a.label.toLowerCase() > b.label.toLowerCase()) return 1
				return 0
			})
		}

		return {
			template: template,
			support: {
				snapshot: false,
				export: false,
				exportData: false
			},
			initialProperties: {
				navbarButtons: []
			},
			definition : {
				type : "items",
				component : "accordion",
				items: {
					settings: {
						uses: "settings",
						items: {
							navbarOptions: {
								label: "Options",
								ref: "navbarOptions",
								type: "items",
								items: {
									navbarOrientation: {
										label: "Orientation",
										type: "string",
										component: "dropdown",
										ref: "navbarOrientation",
										options: [ 
											{ value: "horizontal", label: "Horizontal" }, 
											{ value: "vertical", label: "Vertical" }
										],
										defaultValue: "horizontal"
									},
									navbarAlignment: {
										label: "Alignment",
										type: "string",
										component: "dropdown",
										ref: "navbarAlignment",
										options: [
											{ value: "top-left", label: "Top Left", tooltip: "Align to the top left"},
											{ value: "top-center", label: "Top Center", tooltip: "Align to the center at the top"},
											{ value: "top-right", label: "Top Right", tooltip: "Align to the top right"},
											{ value: "middle-left", label: "Middle Left", tooltip: "Align to the middle left"},
											{ value: "middle-center", label: "Middle Center", tooltip: "Align to the center in the middle"},
											{ value: "middle-right", label: "Middle Right", tooltip: "Align to the middle right"},
											{ value: "bottom-left", label: "Bottom Left", tooltip: "Align to the bottom left"},
											{ value: "bottom-center", label: "Bottom Center", tooltip: "Align to the center at the bottom"},
											{ value: "bottom-right", label: "Bottom Right", tooltip: "Align to the bottom right"},
										],
										defaultValue: "top-left"
									},
									workInEditMode: {
										label: "Work in edit mode?",
										ref: "workInEditMode",
										type: "boolean",
										component: "switch",
										options: [
											{ value: true, label: "Yes"},
											{ value: false, label: "No"}
										],
										defaultValue: false
									},
									navbarSpacing: {
										label: "Spacing",
										type: "string",
										component: "dropdown",
										ref: "navbarSpacing",
										options: [
											{ value: "normal", label: "Normal" },
											{ value: "fill", label: "Fill" },
											{ value: "space-around", label: "Space Around" },
											{ value: "space-between", label: "Space Between" },
										],
										defaultValue: "normal"
									},
									navbarStyling: {
										label: "Button Style",
										type: "string",
										component: "dropdown",
										ref: "navbarStyling",
										options: [
											{ value: "primary", label: "Primary"},
											{ value: "secondary", label: "Secondary"},
											{ value: "buttonLight", label: "Button Light"},
											{ value: "button", label: "Button Dark"},
											{ value: "switch", label: "Switch/Toggle"}
										],
										defaultValue: "primary"
									},
									navbarFont: {
										label: "Font",
										type: "string",
										component: "dropdown",
										ref: "navbarFont",
										options: [
											{ value: "Arial", label: "Arial"},
											{ value: "Futura PT", label: "Futura PT"},
											{ value: "Futura PT Light", label: "Futura PT Light"},
											{ value: "Futura PT Bold", label: "Futura PT Bold"},
											{ value: "Qlikview Sans", label: "Qlikview Sans"}
										],
										default: "Arial"
									},
									navbarFontsize: {
										label: function(data) {
											return "Font Size: " + data.navbarFontsize + "px"
										},
										type: "integer",
										component: "slider",
										ref: "navbarFontsize",
										defaultValue: 16,
										min: 10,
										max: 60,
										step: 1
									},
									navbarShowBorder: {
										type: "boolean",
										ref: "navbarShowBorder",
										label: "Show button border?",
										defaultValue: false,
									},
									navbarCustomButtonSizing: {
										type: "boolean",
										ref: "navbarCustomButtonSizing",
										label: "Enter custom button sizing?",
										defaultValue: false
									},
									navbarCustomButtonSizingHeight: {
										type: "string",
										ref: "navbarCustomButtonSizingHeight",
										label: "height",
										show: function(data) {return data.navbarCustomButtonSizing}
									},
									navbarCustomButtonSizingMinHeight: {
										type: "string",
										ref: "navbarCustomButtonSizingMinHeight",
										label: "min-height",
										show: function(data) {return data.navbarCustomButtonSizing}
									},
									navbarCustomButtonSizingMaxHeight: {
										type: "string",
										ref: "navbarCustomButtonSizingMaxHeight",
										label: "max-height",
										show: function(data) {return data.navbarCustomButtonSizing}
									},
									navbarCustomButtonSizingWidth: {
										type: "string",
										ref: "navbarCustomButtonSizingWidth",
										label: "width",
										show: function(data) {return data.navbarCustomButtonSizing}
									},
									navbarCustomButtonSizingMinWidth: {
										type: "string",
										ref: "navbarCustomButtonSizingMinWidth",
										label: "min-width",
										show: function(data) {return data.navbarCustomButtonSizing}
									},
									navbarCustomButtonSizingMaxWidth: {
										type: "string",
										ref: "navbarCustomButtonSizingMaxWidth",
										label: "max-width",
										show: function(data) {return data.navbarCustomButtonSizing}
									}
								}
							}
						}
					},
					navbarButtons: {
						type: "array",
						ref: "navbarButtons",
						label: "Buttons",
						itemTitleRef: "buttonLabel",
						allowAdd: true,
						allowRemove: true,
						addTranslation: "Add Button",
						items: {
							buttonLabel: {
								type: "string",
								ref: "buttonLabel",
								label: "Button Text",
								expression: "optional"
							},
							buttonSelected: {
								type: "string",
								ref: "buttonSelected",
								label: "Selected",
								expression: "always"
							},
							buttonSelectedText: {
								component: "text",
								label: "When expression evaluates to 1 then this button will show as selected."
							},
							buttonDisabled: {
								type: "string",
								ref: "buttonDisabled",
								label: "Disabled",
								expression: "always"
							},
							buttonDisabledText: {
								component: "text",
								label: "When expression evaluates to 1 then this button will show as disabled."
							},
							buttonShow: {
								type: "string",
								expression: "optional",
								ref: "buttonShow",
								label: "Hide/Show"
							},
							buttonShowText: {
								component: "text",
								label: "When expression evaluates to 0 then this button won't be displayed"
							},
							buttonIconShow: {
								type: "boolean",
								ref: "buttonIconShow",
								label: "Include icon?",
								defaultValue: false,
								show: function(data, scope) {
									return scope.layout.navbarStyling !== 'switch'
								}
							},
							buttonIcon: {
								type: "string",
								ref: "buttonIcon",
								show: function(data, scope) {
									return data.buttonIconShow && scope.layout.navbarStyling !== 'switch'
								},
								component: "dropdown",
								options: getIcons()
							},
							buttonIconAlignment: {
								type: "string",
								ref: "buttonIconAlignment",
								label: "Button Alignment",
								show: function(data, scope) {
									return data.buttonIconShow && scope.layout.navbarStyling !== 'switch'
								},
								component: "buttongroup",
								options: [
									{value: "left", label: "Left"},
									{value: "right", label: "Right"}
								],
								defaultValue: "left"
							},
							buttonVariable: {
								type: "string",
								ref: "buttonVariable",
								label: "Enter variable name to switch/toggle",
								expression: "optional",
								show: function(data, scope) {
									return scope.layout.navbarStyling === 'switch'
								}
							},
							buttonSwitchDefault: {
								type: "boolean",
								ref: "buttonSwitchDefault",
								defaultValue: false,
								label: "Default value for switch",
								show: function(data, scope) {
									return scope.layout.navbarStyling === 'switch'
								}
							},
							buttonActions: {
								type: "array",
								ref: "buttonActions",
								label: "Actions",
								itemTitleRef: function(data) {
									return data.actionType;
								},
								allowAdd: true,
								allowRemove: true,
								addTranslation: "Add Action",
								items: {
									actionType: {
										type: "string",
										component: "dropdown",
										ref: "actionType",
										label: "Select an action",
										options: [
											{ value: "setVariable", label: "Set variable" },
											{ value: "selectInField", label: "Select in field"},
											{ value: "clearField", label: "Clear a field"},
											{ value: "clearAllFields", label: "Clear ALL fields"},
											{ value: "gotoSheet", label: "Go to sheet"},
											{ value: "gotoUrl", label: "Go to URL"},
											{ value: "lockField", label: "Lock a field for selection" },
											{ value: "unlockField", label: "Unlock a field for selection" },
											{ value: "runReport", label: "Generate a PDF report" }
										]
									},
									setVariableName: {
										type: "string",
										ref: "setVariableName",
										label: "Enter variable name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									setVariableValue: {
										type: "string",
										ref: "setVariableValue",
										label: "Enter variable value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									selectInFieldName: {
										type: "string",
										ref: "selectInFieldName",
										label: "Enter field name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldValue: {
										type: "string",
										ref: "selectInFieldValue",
										label: "Enter field value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									clearFieldName: {
										type: "string",
										ref: "clearFieldName",
										label: "Enter field name to clear",
										expression: "optional",
										show: function(data) {
											return data.actionType === "clearField";
										}
									},
									gotoSheetOption: {
										type: "string",
										ref: "gotoSheetOption",
										component: "buttongroup",
										options: [
											{ value: "list", label: "List", tooltip: "Choose the sheet from a list" },
											{ value: "expr", label: "Expr", tooltip: "Define sheet using an expression" }
										],
										defaultValue: "list",
										show: function(data) {
											return data.actionType === "gotoSheet";
										}
									},
									gotoSheetName: {
										type: "string",
										ref: "gotoSheetName",
										label: "Enter sheet name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "expr";
										}
									},
									gotoSheetId: {
										type: "string",
										ref: "gotoSheetId",
										label: "Select a sheet",
										component: "dropdown",
										options: Utilities.getSheetList(),
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "list";
										}
									},
									gotoSheetNewWindow: {
										type: "boolean",
										ref: "gotoSheetNewWindow",
										label: "Open in new window",
										show: function(data) {
											return data.actionType === "gotoSheet";
										},
										defaultValue: false
									},
									gotoSheetNewWindowTitle: {
										type: "string",
										ref: "gotoSheetNewWindowTitle",
										label: "New Window Title",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										}
									},
									gotoSheetShowCurrentSelections: {
										type: "boolean",
										ref: "gotoSheetShowCurrentSelections",
										label: "Show current selections?",
										defaultValue: false,
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										},
									},
									gotoSheetNewWindowResizable: {
										type: "boolean",
										ref: "gotoSheetNewWindowResizable",
										label: "New window resizable?",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										},
										defaultValue: true
									},
									gotoSheetNewWindowHeight: {
										type: "number",
										ref: "gotoSheetNewWindowHeight",
										label: "Height of new window",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										},
										defaultValue: 800
									},
									gotoSheetNewWindowWidth: {
										type: "number",
										ref: "gotoSheetNewWindowWidth",
										label: "Width of new window",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										},
										defaultValue: 500
									},
									gotoSheetNewWindowTop: {
										type: "number",
										ref: "gotoSheetNewWindowTop",
										label: "Top position of new window",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										},
										defaultValue: 200
									},
									gotoSheetNewWindowLeft: {
										type: "number",
										ref: "gotoSheetNewWindowLeft",
										label: "Left position of new window",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetNewWindow;
										},
										defaultValue: 500
									},
									gotoUrlName: {
										type: "string",
										ref: "gotoUrlName",
										label: "Enter URL",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoUrl";
										}
									},
									lockFieldName: {
										type: "string",
										ref: "lockFieldName",
										label: "Enter field name to lock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "lockField";
										}
									},
									unlockFieldName: {
										type: "string",
										ref: "unlockFieldName",
										label: "Enter field name to unlock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "unlockField";
										}
									},
									reportName: {
										type: "string",
										ref: "reportName",
										label: "Report Name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "runReport";
										}
									},
									reportEnvironment: {
										type: "string",
										ref: "reportEnvironment",
										label: "Environment to create report",
										expression: "optional",
										show: function(data) {
											return data.actionType === "runReport";
										}
									},
									reportUser: {
										type: "string",
										ref: "reportUser",
										label: "User Info - OSUser()",
										expression: "always",
										show: function(data) {
											return data.actionType === "runReport";
										}
									},
									reportApp: {
										type: "string",
										ref: "reportApp",
										label: "App ID - DocumentName()",
										expression: "optional",
										show: function(data) {
											return data.actionType === "runReport";
										}
									},
									reportStaticSelections: {
										type: "string",
										ref: "reportStaticSelections",
										label: "Selections - Field1|Value1¬Value2|Field2|Value1| OR use GetCurrentSelections('|','|','¬')",
										expression: "optional",
										show: function(data) {
											return data.actionType === "runReport";
										}
									},
									reportSheetCount: {
										type: "string",
										ref: "reportSheetCount",
										label: "Add up the pages from your report options",
										expression: "optional",
										show: function(data) {
											return data.actionType === "runReport";
										}
									},
									reportIncludeAppendix: {
										type: "string",
										ref: "reportIncludeAppendix",
										label: "Enter 1 to include appendix",
										expression: "optional"
									},
									reportSheets: {
										type: "array",
										ref: "reportSheets",
										label: "Sheets",
										itemTitleRef: "sheetId",
										allowAdd: true,
										allowRemove: true,
										addTranslation: "Add Sheet",
										items: {
											sheetId: {
												type: "string",
												ref: "sheetId",
												label: "Select a sheet",
												component: "dropdown",
												options: Utilities.getSheetList()
											},
											sheetStaticSelections: {
												type: "string",
												ref: "sheetStaticSelections",
												label: "Selections - Field1|Value1¬Value2|Field2|Value1| OR use GetCurrentSelections('|','|','¬')",
												expression: "optional",
											},
											sheetLoopingField: {
												type: "string",
												ref: "sheetLoopingField",
												label: "Select a Field to loop the sheet",
												component: "dropdown",
												options: Utilities.getFieldList()
											},
											// sheetLoopingFieldValues: {
											// 	type: "string",
											// 	ref: "sheetLoopingFieldValues",
											// 	label: "Use Concat(distinct field, ',') to pass field values",
											// 	expression: "optional"
											// }
											addAppendix: {
												type: "boolean",
												ref: "addAppendix",
												label: "Add appendix to sheet?",
												defaultValue: false
											},
											appendixSheetId: {
												type: "string",
												ref: "appendixSheetId",
												label: "Select a sheet",
												component: "dropdown",
												options: Utilities.getSheetList(),
												show: function(data) {
													return data.addAppendix
												}
											},
											appendixLoopingField: {
												type: "string",
												ref: "appendixLoopingField",
												label: "Select a Field to loop the appendix sheet",
												component: "dropdown",
												options: Utilities.getFieldList(),
												show: function(data) {
													return data.addAppendix
												}
											},
										}
									}
								}
							}
						}
					},
					about: {
						label: "About",
						component: {
							template: '<div style="width:95%;padding-left:10px;"><p>Extension: <b>{{extensionName}}</b></p><p>Version: <b>{{extensionVersion}}</b></p><p>Author: <b>{{extensionAuthor}}</b></p><p>Released: <b>{{extensionReleased}}</b></p></div>',
							controller: ["$scope", function($scope) {
								$scope.extensionName = "AIG Navbar";
								$scope.extensionVersion = "1.3";
								$scope.extensionAuthor = "Graham Fletcher";
								$scope.extensionReleased = "26/02/2019";
							}]
						}
					}
				}
			},
			paint: function ($element, layout) {

				return qlik.Promise.resolve();
			},
			controller: ['$scope', '$sce', '$http', '$window', '$rootScope', 'luiDialog', function ( $scope, $sce, $http, $window, $rootScope, luiDialog ) {

				$scope.openDialog = function(sheetCount, includeAppendix) {
					luiDialog.show({
						template: dialogTemplate,
						controller: ['$scope', '$window', function scope($scope, $window) {
							$scope.text = 'Your report will download automatically and the page will refresh when completed.'
							$scope.reportStatus = 'loading'
							var adjSheetCount = includeAppendix ? (sheetCount * 4) + 45 : (sheetCount * 2.5) + 23 
							var tm = new Date().getTime() + (adjSheetCount * 1000)
							var progressCounterFn = setInterval(function() {
								var secondsPassed = (tm - new Date().getTime()) / 1000
								var percentComplete = Math.floor(Math.min((1 - (secondsPassed / (adjSheetCount))) * 100 , 100))
								document.querySelector('#page-counter').innerText = 'page '+ Math.ceil(percentComplete / 100 * sheetCount) + ' of ' + sheetCount
								document.querySelector('#progressbar > div').style.width = percentComplete + "%"
							}, 250)
							// $scope.$on('report-started', function() {
							// 	$scope.reportStatus = 'loading'
							// 	$scope.text = 'Your report will download automatically and the page will refresh when completed.'
							// })
							$scope.$on('report-complete', function() {
								clearInterval(progressCounterFn)
								$scope.reportStatus = 'complete'
								$scope.text = ''
							})

							$scope.reloadPage = function() {
								$window.location.reload(true)
							}
						}]
					})
				}
				
				$scope.completeReport = function() {
					$rootScope.$broadcast('report-complete')
				}

				//Stores the sheet list to scope for use later
				Utilities.getSheetList().then(function(sheets) {
					$scope.sheetList = sheets;
				})

				$scope.switchUpdate = function(variable, value) {
					app.variable.setNumValue(variable, value ? 1 : 0)
				}

				var getAvailableFieldValues = function(name) {
					var field = app.field(name).getData()
					return field.rows.filter(function(row) { return row.qState === "O" || row.qState === "S"}).map(function(row) { return row.qText })
				}
				window.getAvailableFieldValues = getAvailableFieldValues

				//Function to get the sheet id from given name
				var getSheetId = function(name) {
					return $scope.sheetList.filter(function(sheet) {
						return sheet.label === name;
					})[0].value
				}

				//Set a variable action function
				var setVariable = function(name, value) {
					switch (typeof value) {
						case "string":
							app.variable.setStringValue(name, value);
							break;
						case "number":
							app.variable.setNumValue(name, value);
							break;
					}
				};

				//Select in field action function
				var selectInField = function(name, value) {
					var valueArray, range = false;
					
					if (value.indexOf("¬") !== -1) {
						valueArray = value.split("¬").map(function(valueItem) {
							return isNaN(valueItem) ? valueItem : parseInt(valueItem);
						})
					} else {
						range = value.indexOf("<") !== -1 || value.indexOf(">") !== -1 ? true : false;
						valueArray = [isNaN(value) ? value : parseInt(value)]
					}
					if (range) {
						app.field(name).selectMatch(valueArray[0], true);
					} else {
						app.field(name).selectValues(valueArray, true, true);
					}
				}
				window.selectInField = selectInField

				//Clear field action function
				var clearField = function(name) {
					app.field(name).clear();
				}
				window.clearField = clearField

				//Clear ALL fields action function
				var clearAllFields = function() {
					app.clearAll();
				}

				//Function to go to sheet using the sheet id
				var gotoSheet = function(sheetId, action) {
					if (action.gotoSheetNewWindow) {
						var sheetUrl =  $sce.trustAsResourceUrl('/single/?appid=' + app.id + '&sheet=' + sheetId + (action.gotoSheetShowCurrentSelections ? '&opt=currsel' : ''));
						var options = "resizable=" + (action.gotoSheetNewWindowResizable ? 'yes' : 'no')
						options += ",height=" + action.gotoSheetNewWindowHeight
						options += ",width=" + action.gotoSheetNewWindowWidth
						options += ",top=" + action.gotoSheetNewWindowTop
						options += ",left=" + action.gotoSheetNewWindowLeft

						window.open(sheetUrl, action.gotoSheetNewWindowTitle, options )

					} else {
						qlik.navigation.gotoSheet(sheetId);
					}
				}

				//Function to lock a field for selections
				var lockField = function(name) {
					app.field(name).lock();
				}

				//Function to unlock a field for selections
				var unlockField = function(name) {
					app.field(name).unlock();
				}

				//Function to run report
				var runReport = function(name, environment, user, appId, staticSelections, sheets, sheetCount, includeAppendix) {

					$scope.openDialog(sheetCount, includeAppendix === '1')

					var checkForError = setInterval(function() {
						if (document.querySelector('button[tid="alert-dialog-close"]')) {
							clearInterval(checkForError)
							document.querySelector('button[tid="alert-dialog-close"]').parentElement.parentElement.parentElement.parentElement.style.visibility = 'hidden'
						}
					}, 10)

					$http({
						method: 'POST',
						url: 'https://4868sense' + (environment === 'PROD' ? '' : environment) + '.aig.net:7374/report/generate',
						data: {
							name: name, 
							environment: environment,
							user: user, 
							app: appId,
							staticSelections: staticSelections,
							sheets: sheets,
							includeAppendix: includeAppendix === '1'
						},
						responseType: "blob",
						headers: {'Content-Type': 'application/json'}
					}).then(function(response) {
						console.log(response)

						var blob = new Blob([response.data], {type:'application/pdf'})

						saveAs(blob, name + '.pdf')
						
					}).then(function() {
						$scope.completeReport()

						setTimeout(function() {
							$window.location.reload(true)
						}, 1000)
					})
				}

				//Handle Action function
				$scope.onButtonClick = function(actions, workInEditMode) {

					if (qlik.navigation.getMode() === 'edit' && !workInEditMode) return;

					actions.forEach(function(action) {
						switch (action.actionType) {
							case "setVariable":
								setVariable(action.setVariableName, action.setVariableValue);
								break;
							case "selectInField":
								selectInField(action.selectInFieldName, action.selectInFieldValue.replace(/\"/g, ""));
								break;
							case "clearField":
								clearField(action.clearFieldName);
								break;
							case "clearAllFields":
								clearAllFields();
								break;
							case "gotoSheet":
								switch (action.gotoSheetOption) {
									case "expr":
										gotoSheet(getSheetId(action.gotoSheetName), action);
										break;
									case "list":
										gotoSheet(action.gotoSheetId, action);
										break;
								}
								break;
							case "gotoUrl":
								var urlPrefix = action.gotoUrlName.indexOf("http") > -1 ? "" : "http://";
								window.open(urlPrefix + action.gotoUrlName);
								break;
							case "lockField":
								lockField(action.lockFieldName);
								break;
							case "unlockField":
								unlockField(action.unlockFieldName);
								break;
							case "runReport":
								runReport(action.reportName, action.reportEnvironment, action.reportUser, action.reportApp, action.reportStaticSelections, action.reportSheets, action.reportSheetCount, action.reportIncludeAppendix);
								break;
						}
					})
				};

			}]
		};
	} );
