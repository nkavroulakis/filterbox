define(["qlik", 'ng!$q'], function(qlik, $q) {

    var app = qlik.currApp(this);

  	return {
		getMasterObjectList: function () {
			var defer = $q.defer();

			app.getList( 'masterobject', function ( data ) {
				var masterobject = [];
				var sortedData = _.sortBy( data.qAppObjectList.qItems, function ( item ) {
						return item.qData.rank;
				});

				_.each( sortedData, function ( item ) {
					masterobject.push({ value: item.qInfo.qId, label: item.qMeta.title });
				});

				return defer.resolve( masterobject );
			});
			return defer.promise;
		},

		getFieldList: function () {
			var defer = $q.defer();

			app.getList( 'FieldList', function ( data ) {
				var fields = data.qFieldList.qItems.map(function(field) {
					return { value: field.qName, label: field.qName };
				});

				return defer.resolve( fields );
			});
			return defer.promise;
		},
	
		getSheetList: function () {
			var defer = $q.defer();

			app.getAppObjectList( 'sheet', function ( data ) {

				var objects = [];
					var sortedData = _.sortBy( data.qAppObjectList.qItems, function ( item ) {
						return item.qData.rank;
				});

				_.each( sortedData, function ( item ) {
					objects.push({
						label: item.qMeta.title, 
						value: item.qInfo.qId
					});
				});

				return defer.resolve( objects );
			});
			return defer.promise;
		},

		getSheetObjectList: function (sheet) {
			var defer = $q.defer();

			app.getAppObjectList( 'sheet', function ( data ) {

				var objectList = [];
					var sortedData = _.sortBy( data.qAppObjectList.qItems, function ( item ) {
						return item.qData.rank;
				});

				_.each( sortedData, function ( item ) {
					if(sheet === item.qInfo.qId)
						objectList = _.values(item.qData.cells);
				});

				return defer.resolve( objectList );
			});
			return defer.promise;
		}
	}
});
