define( [
		"qlik", 
		"text!./AIG_Controller_v2.html", 
		"./Utilities", 
		"./node_modules/leonardo-ui/dist/leonardo-ui.min",
		"css!./css/AIG_Controller_v2.css"
	],
	function ( 
		qlik, 
		template, 
		Utilities,
		leonardoui
	) {

		var app = qlik.currApp(this);

		return {
			template: template,
			support: {
				snapshot: false,
				export: true,
				exportData: false
			},
			initialProperties: {
				sheetActions: []
			},
			definition : {
				type : "items",
				component : "accordion",
				items: {
					settings: {
						uses: "settings",
						items: {
							headerOptions: {
								label: "Header Options",
								ref: "headerOptions",
								type: "items",
								items: {
									headerShow: {
										label: "Show Header?",
										ref: "AIG_HeaderShow",
										type: "boolean",
										component: "switch",
										options: [
											{ value: true, label: "Show"},
											{ value: false, label: "Hide"}
										],
										defaultValue: true
									},
									headerText: {
										label: "Main Header Text",
										ref: "AIG_HeaderText",
										type: "string",
										expression: "optional",
										show: function(data) {
											return data.AIG_HeaderShow
										}
									},
									rightHeaderText: {
										label: "Right Header Text",
										ref: "AIG_RightHeaderText",
										type: "string",
										expression: "optional",
										show: function(data) {
											return data.AIG_HeaderShow
										}
									},
									enableStories: {
										label: "Allow Story Mode?",
										ref: "AIG_StoriesEnabled",
										type: "boolean",
										component: "switch",
										options: [
											{ value: true, label: "Yes"},
											{ value: false, label: "No"}
										],
										defaultValue: true
									},
									enableBookmarks: {
										label: "Allow Bookmarks?",
										ref: "AIG_BookmarksEnabled",
										type: "boolean",
										component: "switch",
										options: [
											{ value: true, label: "Yes"},
											{ value: false, label: "No"}
										],
										defaultValue: true
									},
									showAdmin: {
										label: "Enter expression to hide admin button",
										description: "Return 0 to hide admin button from user.",
										ref: "AIG_ShowAdmin",
										type: "string",
										expression: "always"
									},
									hideSelectionBar: {
										label: "Hide Current Selections?",
										ref: "AIG_HideSelections",
										type: "boolean",
										component: "switch",
										options: [
											{ value: true, label: "Yes"},
											{ value: false, label: "No"}
										],
										defaultValue: false
									},
								}
							},
							sheetActions: {
								type: "array",
								ref: "sheetActions",
								label: "Sheet Actions",
								itemTitleRef: function(data) {
									return data.actionType;
								},
								allowAdd: true,
								allowRemove: true,
								addTranslation: "Add Action",
								items: {
									actionType: {
										type: "string",
										component: "dropdown",
										ref: "actionType",
										label: "Select an action",
										options: [
											{ value: "setVariable", label: "Set variable" },
											{ value: "selectInField", label: "Select in field"},
											{ value: "clearField", label: "Clear a field"},
											{ value: "clearAllFields", label: "Clear ALL fields"},
											{ value: "gotoSheet", label: "Go to sheet"},
											{ value: "gotoUrl", label: "Go to URL"},
											{ value: "lockField", label: "Lock a field for selection" },
											{ value: "unlockField", label: "Unlock a field for selection" }
										]
									},
									setVariableName: {
										type: "string",
										ref: "setVariableName",
										label: "Enter variable name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									setVariableValue: {
										type: "string",
										ref: "setVariableValue",
										label: "Enter variable value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									selectInFieldName: {
										type: "string",
										ref: "selectInFieldName",
										label: "Enter field name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldValue: {
										type: "string",
										ref: "selectInFieldValue",
										label: "Enter field value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldToggleSelect: {
										type: "boolean",
										label: "Toggle select?",
										ref: "selectInFieldToggleSelect",
										defaultValue: true,
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									clearFieldName: {
										type: "string",
										ref: "clearFieldName",
										label: "Enter field name to clear",
										expression: "optional",
										show: function(data) {
											return data.actionType === "clearField";
										}
									},
									gotoSheetOption: {
										type: "string",
										ref: "gotoSheetOption",
										component: "buttongroup",
										options: [
											{ value: "list", label: "List", tooltip: "Choose the sheet from a list" },
											{ value: "expr", label: "Expr", tooltip: "Define sheet using an expression" }
										],
										defaultValue: "list",
										show: function(data) {
											return data.actionType === "gotoSheet";
										}
									},
									gotoSheetName: {
										type: "string",
										ref: "gotoSheetName",
										label: "Enter sheet name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "expr";
										}
									},
									gotoSheetId: {
										type: "string",
										ref: "gotoSheetId",
										label: "Select a sheet",
										component: "dropdown",
										options: Utilities.getSheetList(),
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "list";
										}
									},
									gotoUrlName: {
										type: "string",
										ref: "gotoUrlName",
										label: "Enter URL",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoUrl";
										}
									},
									lockFieldName: {
										type: "string",
										ref: "lockFieldName",
										label: "Enter field name to lock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "lockField";
										}
									},
									unlockFieldName: {
										type: "string",
										ref: "unlockFieldName",
										label: "Enter field name to unlock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "unlockField";
										}
									}
								}
							},
							themeOptions: {
								label: "Theme Options",
								ref: "themeOptions",
								type: "items",
								items: {
									applyCustomTheme: {
										type: "boolean",
										component: "switch",
										ref: "applyCustomTheme",
										label: "Apply custom theme?",
										defaultValue: false,
										options: [
											{value: true, label: "Yes"},
											{value: false, label: "No"}
										]
									},
									customThemeName: {
										type: "string",
										ref: "customThemeName",
										label: "Enter theme name",
										expression: "optional",
										show: function(data) {
											return data.applyCustomTheme
										}
									},
									customThemeApplyBtn: {
										component: "button",
										label: "Apply Theme",
										ref: "customThemeApplyBtn",
										show: function(data) {
											return data.applyCustomTheme
										},
										action: function(data) {
											qlik.theme.apply(data.customThemeName)
										}
									}
								}
							},
							about: {
								label: "About",
								component: {
									template: '<div style="width:95%;padding-left:10px;"><p>Extension: <b>{{extensionName}}</b></p><p>Version: <b>{{extensionVersion}}</b></p><p>Author: <b>{{extensionAuthor}}</b></p><p>Released: <b>{{extensionReleased}}</b></p></div>',
									controller: ["$scope", function($scope) {
										$scope.extensionName = "AIG Controller";
										$scope.extensionVersion = "2.1";
										$scope.extensionAuthor = "Graham Fletcher";
										$scope.extensionReleased = "09/11/2018";
									}]
								}
							}
						}
					}
				}
			},
			resize: function ($element, layout) {

			},
			paint: function ($element, layout) {

				createCookie('AIG_StoryMode', 'off')

				if( $($('button[tid="2f7a7e"]').parent()).attr('id') !== 'AIG-story-nav-btn-wrap' ) $('button[tid="2f7a7e"]').wrap($('#AIG-story-nav-btn-wrap'));
				if( $($('button[tid="4e25a2"]').parent()).attr('id') !== 'AIG-story-sheet-btn-wrap' ) $('button[tid="4e25a2"]').wrap($('#AIG-story-sheet-btn-wrap'));

				if( $('.qui-buttonset-right').find('#AIG-story-home-btn').length === 0 ) {
					$('.qui-buttonset-right').append($('#AIG-story-home-btn'))
				} else if ($('.qui-buttonset-right').find('#AIG-story-home-btn').length && $('.qv-object-AIG_Controller_v2').find('#AIG-story-home-btn').length) {
					$('.qui-buttonset-right').find('#AIG-story-home-btn').replaceWith($('.qv-object-AIG_Controller_v2').find('#AIG-story-home-btn'))
				}

				var currentSheet = qlik.navigation.getCurrentSheetId().sheetId;
				// Function for additional home button added to toolbar during story mode
				$('#AIG-story-home-btn').off().on('click', function() {
					createCookie('AIG_StoryMode', 'off');
					$('#AIG-story-nav-btn-wrap').css("display", "");
					$('#AIG-story-sheet-btn-wrap').css("display", "");
					$('#AIG-story-home-btn').css("display", "none");
					qlik.navigation.gotoSheet(currentSheet);
				}) 

				// Setup defaults for admin mode
				if (layout.AIG_ShowAdmin.toString() === '0') {
					createCookie('AIG_AdminMode', 'off')
				}
				var adminMode = readCookie('AIG_AdminMode');
				var showHeader = getParamByName(window.location.href, "showheader") || readCookie('AIG_ShowHeader') || '1';
				
				if ( adminMode == null ) {
					if (qlik.navigation.getMode() === 'edit') {
						createCookie('AIG_AdminMode', 'on');
					} else {
						createCookie('AIG_AdminMode', 'off');
						$('.qui-toolbar').find("*").css("height", "0px");
						$('.qui-toolbar').css("height", "0px");
						$('.AIG_Header #admin-mode').prop('checked', false);
					}
				} else {
					if (adminMode === 'on' && showHeader !== '0') {
						$('.qui-toolbar').find("*").css("height", "28px");
						$('.qui-toolbar').css("height", "42px");
						$('.AIG_Header #admin-mode').prop('checked', true);
					} else if (adminMode === 'off' || (adminMode === 'on' && showHeader === '0')) {
						$('.qui-toolbar').find("*").css("height", "0px");
						$('.qui-toolbar').css("height", "0px");
						$('.AIG_Header #admin-mode').prop('checked', false);
					}
				}

				// Add header to top of page and remove dead one from any sheet navigation changes
				if( $($('.qv-panel-wrap').children()[0]).hasClass('AIG_Header') && $('[tid="qv-object-AIG_Controller_v2"').find('.AIG_Header').length ) $($('.qv-panel-wrap').children()[0]).remove()
				$('.qv-panel-wrap').prepend($('.AIG_Header'))

				//Add controller to top of sheet when in a single window popout
				if($('#single-object')) $('#single-object').prepend($('.AIG_Header'))

				// Update panel height
				updatePanelHeight(layout)

				// Add function for menu button action
				$('.AIG_Header .menu-button').off().on('click', function() {
					$('.AIG_Header .menu-content').slideToggle()
				})

				// Add function for when admin mode button is changed
				$('#admin-mode').change(function() {
					if(this.checked) {
						$('.qui-toolbar').find("*").css("height", "28px");
						$('.qui-toolbar').css("height", "42px");
						createCookie('AIG_AdminMode', 'on');
					} else {
						$('.qui-toolbar').find("*").css("height", "0px");
						$('.qui-toolbar').css("height", "0px");
						createCookie('AIG_AdminMode', 'off');
					}
					updatePanelHeight(layout)
					qlik.resize()
				});

				// Apply AIGblue theme if custom theme not being set
				if (!layout.applyCustomTheme) qlik.theme.apply('AIGblue');
				$('.sheet-title-container').hide()

				// Create new or replace old bookmarks button on selection bar for non admin users
				if (!$('.qv-selections-pager #AIG-toolbar-btn.lui-icon--bookmark').length) {
					$("div.buttons-end").append($('#AIG-toolbar-btn.lui-icon--bookmark'))
				} else if ($('.qv-selections-pager #AIG-toolbar-btn.lui-icon--bookmark').length && $('.qv-object-AIG_Controller_v2').find('#AIG-toolbar-btn.lui-icon--bookmark').length) {
					$("div.buttons-end").find('#AIG-toolbar-btn.lui-icon--bookmark').replaceWith($('.qv-object-AIG_Controller_v2').find('#AIG-toolbar-btn.lui-icon--bookmark'))
				}

				// Apply click event to actual bookmark button
				$('#AIG-toolbar-btn.lui-icon--bookmark').off().on('click', function() {
					$("button[tid='4e4ab2']").trigger('click');
				})
				
				// Create new stories button on selection bar for non admin users
				if (!$('.qv-selections-pager #AIG-toolbar-btn.lui-icon--slide-show').length) {
					$("div.buttons-end").append($('#AIG-toolbar-btn.lui-icon--slide-show'))
				} else if ($('.qv-selections-pager #AIG-toolbar-btn.lui-icon--slide-show').length && $('.qv-object-AIG_Controller_v2').find('#AIG-toolbar-btn.lui-icon--slide-show').length) {
					$("div.buttons-end").find('#AIG-toolbar-btn.lui-icon--slide-show').replaceWith($('.qv-object-AIG_Controller_v2').find('#AIG-toolbar-btn.lui-icon--slide-show'))
				}
				
				// Apply click event to actual story button
				$('#AIG-toolbar-btn.lui-icon--slide-show').off().on('click', function() {
					$("button[tid='4e25a3']").trigger('click');

					$('ul[qv-sortable-list="storySortableItemLists"] > li > div .qv-thumb-wrap').off().on("click", function() {
	
						createCookie('AIG_StoryMode', 'on');

						$('.qui-toolbar').find("*").css("height", "28px");
						$('.qui-toolbar').css("height", "42px");

						$('#AIG-story-nav-btn-wrap').css("display", "none");
						$('#AIG-story-sheet-btn-wrap').css("display", "none");
						$('#AIG-story-home-btn').css("display", "");
					})

					// Add click event setup for toolbar in story mode when a new story is created
					$('.qv-add-cont').off().on('click', function() {
						return setTimeout(function() {
							$('ul[qv-sortable-list="storySortableItemLists"] > li > div .qv-thumb-wrap').off().on("click", function() {
							
								createCookie('AIG_StoryMode', 'on');

								$('.qui-toolbar').find("*").css("height", "28px");
								$('.qui-toolbar').css("height", "42px");

								$('#AIG-story-nav-btn-wrap').css("display", "none");
								$('#AIG-story-sheet-btn-wrap').css("display", "none");
								$('#AIG-story-home-btn').css("display", "");
							})
						}, 400)
					})
					
				})

				// Add click event setup for when native story mode button clicked
				$("button[tid='4e25a3']").on('click', function() {
					$('ul[qv-sortable-list="storySortableItemLists"] > li > div .qv-thumb-wrap').off().on("click", function() {
					
						createCookie('AIG_StoryMode', 'on');

						$('.qui-toolbar').find("*").css("height", "28px");
						$('.qui-toolbar').css("height", "42px");

						$('#AIG-story-nav-btn-wrap').css("display", "none");
						$('#AIG-story-sheet-btn-wrap').css("display", "none");
						$('#AIG-story-home-btn').css("display", "");
					})

					
					// Add click event setup for toolbar in story mode when a new story is created
					$('.qv-add-cont').off().on('click', function() {
						return setTimeout(function() {
							$('ul[qv-sortable-list="storySortableItemLists"] > li > div .qv-thumb-wrap').off().on("click", function() {
							
								createCookie('AIG_StoryMode', 'on');

								$('.qui-toolbar').find("*").css("height", "28px");
								$('.qui-toolbar').css("height", "42px");

								$('#AIG-story-nav-btn-wrap').css("display", "none");
								$('#AIG-story-sheet-btn-wrap').css("display", "none");
								$('#AIG-story-home-btn').css("display", "");
							})
						}, 400)
					})

				})

				if (layout.AIG_HideSelections) {
					$('.qv-panel-current-selections').hide()
				} else {
					$('.qv-panel-current-selections').show()
				}

				

				// The code for the function stuff is getting repeated a lot of times so need to make this DRY
				// console.log(this)
				return qlik.Promise.resolve();
			},
			controller: ['$scope', '$timeout', '$http', function ( $scope, $timeout, $http ) {

				$scope.showheaderFromUrl = getParamByName(window.location.href, "showheader") || readCookie('AIG_ShowHeader') || '1';
				createCookie('AIG_ShowHeader', $scope.showheaderFromUrl)

				//Add popover functionality to email menu button
				var popoverTriggers = document.querySelectorAll( "#menu-item-email" );
				popoverTriggers = [].slice.apply( popoverTriggers ); // convert to array
				popoverTriggers.forEach( function ( element, idx ) {
					element.addEventListener( "click", function() {
						var popover = leonardoui.popover( {
							content: element.nextElementSibling.innerHTML,
							closeOnEscape: true,
							dock: idx === 0 ? "bottom" : "right",
							alignTo: element
						} );
						// Popover was shown
						var closeButton = popover.element.querySelectorAll( ".close-button" )[0];
						closeButton.addEventListener( "click", function() {
							popover.close();
						} );

						/*
							TODO:
							- Include screenshot (including loading icon)
							- Embed screenshot into email
							- Options for TO email input
							- Make Name prompt the sender in the email
							- Include app details within email (in background)

							Workflow:
							- Create Report
								- options for report title, loop field etc..??
								- confirm or cancel
								- display loading icon
								- download report and provide link to open or close window

							- Email Screenshot
								- display loading icon
								- display image in popout
									- add drawing?
										- show drawing tools
									- send as email?
										- show email inputs with send button
							
						*/

						var sendEmailButton = popover.element.querySelectorAll(".send-email-button")[0];
						sendEmailButton.addEventListener( "click", function() {
							$http({
								method: 'POST',
								url:"http://10.116.196.222:3002/send",
								data: {
									name: popover.element.querySelector('.aig-form-name').value || '',  
									email: popover.element.querySelector('.aig-form-email').value || '', 
									message: popover.element.querySelector('.aig-form-message').value || '', 
								}
							}).then(function(response) {
								// console.log("success", response)
							}, function(err) {
								console.log(err)
							})
						} );
					} );
				} );


				// //Check exists function for showing only on pages where extension object exists

				// This kind of works but is pointless as when you go to a new sheet where the object doesnt exist then the controller is not run, so the exist variable not updated
				// Need to run the function from the HTML, maybe in ng-init? or ng-if?

				// $scope.checkControllerExists = function() {
				// 	Utilities.getSheetObjectList().then(function(reply) {
				// 		var currentSheet = reply.qAppObjectList.qItems.find(function(sheet) {
				// 			return sheet.qInfo.qId === qlik.navigation.getCurrentSheetId().sheetId
				// 		})
				// 		var currentObject = currentSheet.qData.cells.find(function(object) {
				// 			return object.type === extensionName
				// 		})
				// 		$scope.AIG_ControllerExists = currentObject ? true : false;
				// 	})
				// }

				// // $scope.checkControllerExists('AIG_Controller_v2')

				//Stores the sheet list to scope for use later
				Utilities.getSheetList().then(function(sheets) {
					$scope.sheetList = sheets;
				});

				//Function to get the sheet id from given name
				var getSheetId = function(name) {
					return $scope.sheetList.filter(function(sheet) {
						return sheet.label === name;
					})[0].value
				}

				//Set a variable action function
				var setVariable = function(name, value) {
					switch (typeof value) {
						case "string":
							app.variable.setStringValue(name, value);
							break;
						case "number":
							app.variable.setNumValue(name, value);
							break;
					}
				};

				//Select in field action function
				var selectInField = function(name, value, toggle) {
					var valueArray, range = false;
					
					if (value.indexOf(",") !== -1) {
						valueArray = value.split(",").map(function(valueItem) {
							return isNaN(valueItem) ? valueItem : parseInt(valueItem);
						})
					} else {
						range = value.indexOf("<") !== -1 || value.indexOf(">") !== -1 ? true : false;
						valueArray = [isNaN(value) ? value : parseInt(value)]
					}
					if (range) {
						app.field(name).selectMatch(valueArray[0], toggle);
					} else {
						app.field(name).selectValues(valueArray, toggle, true);
					}
				}

				//Clear field action function
				var clearField = function(name) {
					app.field(name).clear();
				}

				//Clear ALL fields action function
				var clearAllFields = function() {
					app.clearAll();
				}

				//Function to go to sheet using the sheet id
				var gotoSheet = function(sheetId) {
					qlik.navigation.gotoSheet(sheetId);
				}

				//Function to lock a field for selections
				var lockField = function(name) {
					app.field(name).lock();
				}

				//Function to unlock a field for selections
				var unlockField = function(name) {
					app.field(name).unlock();
				}

				// console.log(typeof $scope.layout.sheetActions[1].selectInFieldValue)
				//Run through and execute actions
				$scope.layout.sheetActions.forEach(function(action) {
					switch (action.actionType) {
						case "setVariable":
							setVariable(action.setVariableName, action.setVariableValue);
							break;
						case "selectInField":
							$timeout(selectInField(action.selectInFieldName, action.selectInFieldValue.replace(/\"/g, ""), action.selectInFieldToggleSelect), 100)
							break;
						case "clearField":
							clearField(action.clearFieldName);
							break;
						case "clearAllFields":
							clearAllFields();
							break;
						case "gotoSheet":
							switch (action.gotoSheetOption) {
								case "expr":
									gotoSheet(getSheetId(action.gotoSheetName));
									break;
								case "list":
									gotoSheet(action.gotoSheetId);
									break;
							}
							break;
						case "gotoUrl":
							var urlPrefix = action.gotoUrlName.indexOf("http") > -1 ? "" : "http://";
							window.open(urlPrefix + action.gotoUrlName);
							break;
						case "lockField":
							lockField(action.lockFieldName);
							break;
						case "unlockField":
							unlockField(action.unlockFieldName);
							break;
					}
				})

            }]
		};

		function getParamByName(url, name){
			var qs = url.substring(url.indexOf('?') + 1).split('&');
			for(var i = 0, result = {}; i < qs.length; i++){
				qs[i] = qs[i].split('=');
				result[qs[i][0]] = decodeURIComponent(qs[i][1]);
			}
			return result[name];
		}

		function updatePanelHeight(layout) {
			var AIG_ToolbarShow = $('.qui-toolbar').css("height") !== "0px";
			
			var showheaderFromUrl = getParamByName(window.location.href, "showheader") || readCookie('AIG_ShowHeader') || '1';
			var AIG_HeaderShow = showheaderFromUrl === '0' ? false : layout.AIG_HeaderShow;

			// Check this for story mode...
			if ( AIG_HeaderShow && AIG_ToolbarShow ) {
				// Header and toolbar showing
				$('.qv-panel').css("height", "calc(100% - 89px)")

			} else if ( AIG_HeaderShow && !AIG_ToolbarShow ) {
				// Header showing but toolbar not showing
				$('.qv-panel').css("height", "calc(100% - 42px)")

			} else if ( !AIG_HeaderShow && AIG_ToolbarShow ) {
				// Header not showing and toolbar showing
				$('.qv-panel').css("height", "calc(100% - 45px)")

			} else if ( !AIG_HeaderShow && !AIG_ToolbarShow ) {
				// Header and toolbar not showing
				$('.qv-panel').css("height", "calc(100%)")

			}
		}

		function createCookie(name,value,days) {
			if (days) {
				var date = new Date();
				date.setTime(date.getTime()+(days*24*60*60*1000));
				var expires = "; expires="+date.toGMTString();
			}
			else var expires = "";
			document.cookie = name + '-' + app.id + "=" + value + expires + "; path=/";
		}
		
		function readCookie(name) {
			var nameEQ = name + '-' + app.id + "=";
			var ca = document.cookie.split(';');
			for(var i=0;i < ca.length;i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1,c.length);
				if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
			}
			return null;
		}
		
		function eraseCookie(name) {
			createCookie(name + '-' + app.id,"",-1);
		}

		function storageAvailable(type) {
			try {
				var storage = window[type],
					x = '__storage_test__';
				storage.setItem(x, x);
				storage.removeItem(x);
				return true;
			}
			catch(e) {
				return e instanceof DOMException && (
					// everything except Firefox
					e.code === 22 ||
					// Firefox
					e.code === 1014 ||
					// test name field too, because code might not be present
					// everything except Firefox
					e.name === 'QuotaExceededError' ||
					// Firefox
					e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
					// acknowledge QuotaExceededError only if there's something already stored
					storage.length !== 0;
			}
		}
	} );
