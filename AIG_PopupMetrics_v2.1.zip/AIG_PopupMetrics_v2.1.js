define(["./AIG_PopupMetrics-properties_v2", "text!./AIG_PopupMetrics_v2.css", "text!./AIG_PopupMetrics_Centre_v2.css", "qlik"],

function ( properties, cssContent, cssContentCentre, qlik) {

	'use strict';
  	//Append CSS To Sheet header
	$("<style>").html(cssContent).appendTo("head");

	//var ffff = layout.UserParameters;

	

	return {
		support : {
			snapshot: false,
			export: false,
			exportData : false
		},
		
		definition : properties,

		resize: function() {

		},
		
		paint: function ($element, layout) {

		    var app = qlik.currApp(this);
		    var appLocation = '/extensions/AIG_PopupMetrics/';


		    var KPI_Parameters = $.parseJSON(layout.UserParameters.AIG_Objects);


		    if ($element.find('.KPI_Popup').length)
		    {
		        /* ONLY RUN IF PAGE ALREADY SETUP */

                //Apply Centre Align CSS If Selected
		        if (layout.UserParameters.AIG_CentreText == true && $("#AIG_Popup_Centre").length<1) {
		            $("<style id='AIG_Popup_Centre'>").html(cssContentCentre).appendTo("head");
		        } else if (layout.UserParameters.AIG_CentreText == false && $("#AIG_Popup_Centre").length > 0) {
		            $("#AIG_Popup_Centre").remove();
		        }

                //Set Max Width
		        if (layout.UserParameters.AIG_MaxTileWidth > -1 && $("#AIG_Popup_MaxWidth").length < 1) {
					$("<style id='AIG_Popup_MaxWidth'>").html(".KPI_Metric, .KPI_Metric_Hover { max-width: " + layout.UserParameters.AIG_MaxTileWidth + "px; }").appendTo("head");
					
		        } else if (layout.UserParameters.AIG_MaxTileWidth == -1 && $("#AIG_Popup_MaxWidth").length > 0) {
		            $("#AIG_Popup_MaxWidth").remove();
		        }

		        


		    }
		    else
		    {
		        /* ONLY RUN THIS SECTION ONCE */
		       


                //BUILD MODAL POPUP
		        $element.append(ShowModal());


		        //Add Class To Enable Scroll
		        $element.addClass('KPI_Override');
		        var f = $('[tid=' + layout.qInfo.qId + ']');
		        $('[tid=' + layout.qInfo.qId + ']').addClass('KPI_ExtensionContainer');
		        $('[tid=qv-object-AIG_PopupMetrics]').addClass('KPI_ExtensionContainer');
		        $('[tid=qv-object-AIG_PopupMetrics]').find('.qv-inner-object').addClass('KPI_ExtensionContainer');

		        var Result = "<div class='KPI_Container'>";
		        for (var i = 0; KPI_Parameters.Groups.length > i; i++) {

		            var CurrSect = KPI_Parameters.Groups[i];
					Result += "<div class='KPI_Section'><div class='KPI_SectionTitle'>" + CurrSect.Section + "</div>";

		            for (var j = 0; CurrSect.Objects.length > j; j++) {
		                Result += "<div class='KPI_Metric' section='" + CurrSect.Section + "'>";
						Result += "<div class='KPI_Metric_Hover'>";
						Result += "<div class='KPI_Metric_HoverText'>View More</div></div>";
						// Result += "<div class='KPI_Metric_Title'><div class='CloseBtn'></div>" + CurrSect.Objects[j].Title + "</div>";
						Result += "<div class='KPI_Metric_Title'>" + CurrSect.Objects[j].Title + "</div>";
						Result += "<div class='KPI_MainContent'>"
						Result += "<div class='qvobject KPI_MainKPI' data-qvid='" + CurrSect.Objects[j].KPIChartID + "'></div>";
						Result += "<div class='qvobject KPI_MainTrend' data-qvid='" + CurrSect.Objects[j].TrendChartID + "'></div>";
						Result += "</div>";
		                Result += "<div class='KPI_CoverLine'></div>";
		                Result += "</div>";
		            }
		            Result += "</div>";
		        }
		        Result += "</div>";

		        $element.append(Result);
		        $element.append("<div class='KPI_Popup' currItem=''><div class='KPI_PopupObjects'></div></div>")


		        //***************************************************************
		        // UPDATE SENSE OBJECTS
		        //***************************************************************
		        $(".qvobject").each(function () {
		            var qvid = $(this).data("qvid");

                    //Prevent User Interaction
		            app.getObject(this, qvid, { "noInteraction": "true" });
		        });

                
		        //***************************************************************
		        // ON KPI CLICK EVENT
		        //***************************************************************
		        $('.KPI_Metric').off().on('click',function () {
					





                    ////// THICKEN LINE
		            //$(".KPI_MainTrend").each(function () {

		            //    var canvas = $(this).find('[tid="line-objects-layer"]').find('canvas');
		            //    var context = canvas[1].getContext('2d');
		            //    context.lineWidth = 3;
		            //    context.setLineDash([10, 8]);
		            //    context.strokeStyle = '#005984';
		            //    context.stroke();

		            //});
		            ////// THICKEN LINE TEST END







		            var ClickedKPIID = $(this).find('.KPI_MainKPI').attr('data-qvid');

		            if ($('.KPI_Popup').is(':visible') && $('.KPI_Popup').attr('currItem') == ClickedKPIID) {
		                $('.KPI_Popup').insertAfter($('.KPI_Container')).hide();

		                $(this).find('.KPI_Metric_HoverText').html('View More');
		                $('.KPI_Metric').removeClass("KPI_Active").removeClass("KPI_Inactive");
		            }
		            else
		            {
                        //Rmeove Active Class From All Tiles
		                $('.KPI_Metric').removeClass("KPI_Active").addClass("KPI_Inactive");

                        //Remove Inactive From Clicked Tile & Add Active CLass
		                $(this).addClass("KPI_Active").removeClass("KPI_Inactive");

                        //Loop Parameters
		                for (var i = 0; KPI_Parameters.Groups.length > i; i++) {
		                    if (KPI_Parameters.Groups[i].Section == $(this).attr('section')) {
		                        for (var j = 0; KPI_Parameters.Groups[i].Objects.length > j; j++) {
		                            var PopObjs = KPI_Parameters.Groups[i].Objects[j];
		                            if (PopObjs.KPIChartID == ClickedKPIID) {
										
										
										//Loop Each Action
										if (typeof KPI_Parameters.Groups[i].Objects[j].Actions !== 'undefined' && KPI_Parameters.Groups[i].Objects[j].Actions.length > 0) {		
		                                for (var k = 0; KPI_Parameters.Groups[i].Objects[j].Actions.length > k; k++) {

		                                    switch (KPI_Parameters.Groups[i].Objects[j].Actions[k].Action.toUpperCase()) {
		                                        case "SHEET":
		                                            qlik.navigation.gotoSheet(KPI_Parameters.Groups[i].Objects[j].Actions[k].Value);
		                                            break;
		                                        case "VARIABLE":
		                                            app.variable.setStringValue(KPI_Parameters.Groups[i].Objects[j].Actions[k].Set, KPI_Parameters.Groups[i].Objects[j].Actions[k].Value);
		                                            break;
		                                        case "SELECT":
		                                            app.field(KPI_Parameters.Groups[i].Objects[j].Actions[k].Set).select([KPI_Parameters.Groups[i].Objects[j].Actions[k].Value], true, true);
		                                            break;
		                                        case "CLEARALL":
		                                            app.clearAll();
		                                            break;
		                                        case "CLEAR":
		                                            app.field(KPI_Parameters.Groups[i].Objects[j].Actions[k].Value).clear();
		                                            break;
		                                    }
		                                }
										}
										
										

		                                //Empty Popup
		                                $('.KPI_PopupObjects').empty().append("<div class='KPI_PopupHeader'></div>");

                                        //Check if Data Table Specified
		                                if (typeof PopObjs.DataTableID !== 'undefined' && PopObjs.DataTableID.length > 0) {		                                    
		                                    var title = '';
		                                    if (typeof PopObjs.DataTableTitle !== 'undefined')
		                                        title = PopObjs.DataTableTitle;

		                                    //Append Data Button To Popup
		                                    $('.KPI_PopupHeader').append("<div class='KPI_PopupHeaderDataBtn'>View Tabular Data</div>");

		                                    //Setup Modal
		                                    SetupModalPopup(app, qlik, PopObjs.DataTableID, title);
		                                }
                                       
                                        //Append Popup Chart Container
		                                $('.KPI_PopupObjects').append("<div class='KPI_PopupChartContainer'></div>");
		                                
                                        //Put Qlik Objects In Popup
										$('.KPI_Popup').attr('currItem', ClickedKPIID);
										var PopupHeaderText = "<span>";
		                                for (var k = 0; PopObjs.PopCharts.length > k; k++) {

		                                    if (PopObjs.PopCharts.length) {
		                                        //Create Sub Tab Button
												// $('.KPI_PopupHeader').append("<div class='KPI_PopupHeaderNavButton " + (k == 0 ? " Active" : "") + "' OptionNum='" + k + "'>" + PopObjs.PopCharts[k].Title + "</div>");
												
												// PopupHeaderText += PopObjs.PopCharts[k].Title;
												// if (k !== PopObjs.PopCharts.length - 1) PopupHeaderText += (k === PopObjs.PopCharts.length - 2 && PopObjs.PopCharts.length > 1 ? " & " : ", " )
		                                    }

                                            //Create Qlik Object
											// $('.KPI_PopupChartContainer').append("<div class='AIG_TBStyle KPI_PopupChart " + (k == 0 ? " Active" : "") + "' OptionNum='" + k + "'><div class='qvobject KPI_PopupQVObject' data-qvid='" + PopObjs.PopCharts[k].PChart + "'></div></div>");
											$('.KPI_PopupChartContainer').append("<div class='AIG_TBStyle KPI_PopupChart Active" + "' OptionNum='" + k + "'><div class='qvobject KPI_PopupQVObject' data-qvid='" + PopObjs.PopCharts[k].PChart + "'></div></div>");
										}

										PopupHeaderText += PopObjs.PopTitle + "</span><div class='CloseBtn'></div>";
										$('.KPI_PopupHeader').append(PopupHeaderText);

										if(PopObjs.PopCharts.length > 3) {
											$('.KPI_PopupChart').css("width", (2 / PopObjs.PopCharts.length * 100) + "%" );
										} else {
											$('.KPI_PopupChart').css("width", (100 / PopObjs.PopCharts.length) + "%" );
										}

                                        // //On Sub Tab Navigation Change
		                                // $('.KPI_PopupHeaderNavButton').click(function () {
		                                //     var OptionNum = $(this).attr('OptionNum');
		                                //     $('.KPI_PopupHeaderNavButton').removeClass("Active");
		                                //     $(this).addClass("Active");
		                                //     $(".KPI_PopupChart").removeClass("Active");
		                                //     $(".KPI_PopupChartContainer").find("[OptionNum='" + OptionNum + "']").addClass("Active");
		                                //     qlik.resize();

		                                //     //Check If Newly Visible Object Is A Table
		                                //     var ObjID = $(".KPI_PopupChartContainer").find("[OptionNum='" + OptionNum + "']").find(".qvobject").data("qvid");
		                                //     CheckIfTable(app, ObjID, '.KPI_PopupObjects');
		                                // });
		                                
                                        //Assign QV Objects to Divs
		                                $('.KPI_PopupObjects').find(".qvobject").each(function () {
		                                    app.getObject(this, $(this).data("qvid"));
		                                    //CheckIfTable(app, $(this).data("qvid"));
		                                });
		                            }
		                        }
		                    }
		                }

						// Call click event on active kpi metric when close button pressed
						$('.CloseBtn').off().on('click', function() {
							$('.KPI_Metric.KPI_Active').trigger('click');
						})

		                //*******************************
		                //Move Popup To Correct Possition
		                //*******************************

                        //Get Top Of Clicked Tile - use this to detect if second row of tiles
		                var clickedTileTop = $(this).position().top;
		                var countOfNextTiles = $(this).nextAll(".KPI_Metric").length;
		                var currTile = this;

		                if (countOfNextTiles > 0) {

		                    var currTile = $(currTile).next(".KPI_Metric");

		                    //Loop Next Tiles in Section - detect next row
		                    for (var i = 0; countOfNextTiles > i; i++) {
		                        if ($(currTile).position().top > clickedTileTop) {
		                            currTile = $(currTile).prev(".KPI_Metric");
		                            break;
		                        } else {
		                            //If Final Iteration Don't Look For Next
		                            if ((countOfNextTiles-1) == i) {
		                                break;
		                            }
		                            currTile = $(currTile).next(".KPI_Metric");
		                        }
		                    }
		                }

                        //Insert Popup Under Current Row of Clicked Tile
		                $('.KPI_Popup').insertAfter($(currTile));
		                
		                //**************END**************

                        //Move Popup To Correct Possition
		              //  $('.KPI_Popup').insertAfter(this.parentNode);




                        //Show Popup
		                $('.KPI_Popup').css('display', 'inline-block');
		                $(this).find('.KPI_Metric_HoverText').html('Hide More');

                        ////Scroll To Popup
		                //var poss = $(this).offset().top - -$('.KPI_Override').scrollTop() - $(this).height();
		                //$('.KPI_Override').animate({
		                //    scrollTop: poss
		                //}, 1000);
                                                
		                //Update Sense Objects
		                // qlik.resize();
		            }		            
		        });


		    }

		    //needed for export
		    return qlik.Promise.resolve();
		}

	};
});

//SETUP MODAL POPUP ON CLICK
function SetupModalPopup(app, qlik, QVObject, Header) {
    //SHOW MODAL
    $('.KPI_PopupHeaderDataBtn').off().on('click',function () {

        //Show MOdal Objects
        $('.AIG_ModalDialog').show();
        $('.AIG_Modal').show();

        //Set Header Text
        $('.AIG_ModalDialog .text').html(Header);

        //Append Data Table
        $('.AIG_ModalBody').empty().append("<div class='qvobject AIG_ModalChart' data-qvid='" + QVObject + "'></div>");

        //Setup Download Data Button
        $('.AIG_ModalDialog .download').off().on('click',function () {
            //Show Loading Icon
            $(this).addClass('loading');
            app.getObjectProperties(QVObject).then(function (model) {
                var qTable = qlik.table(model);
                qTable.exportData({ download: true });
                setTimeout(function () {
                    //Remove Loading Icon
                    $('.AIG_ModalDialog .download').removeClass('loading');
                }, 5000);                
            });
        });

        //Link Qlik Objects
        $('.AIG_ModalBody').find(".qvobject").each(function () {
            app.getObject(this, $(this).data("qvid"));

            //Check If Table
            CheckIfTable(app, $(this).data("qvid"), '.AIG_ModalBody');        
        });

        //Update QLik Objects
        qlik.resize();
    });

    //CLOSE MODAL
    $('.AIG_ModalClose').off().on('click',function () {
        $('.AIG_ModalDialog').hide();
        $('.AIG_Modal').hide();
    });
}

//BUILD MODAL POPUP HTML
function ShowModal() {

    var result = '';
    result += '<div class="AIG_Modal"></div>';
    result += '<div class="AIG_ModalDialog AIG_TBStyle">';
    result += '<div class="content">';
    result += '<div class="header">';
    result += '<div class="close AIG_ModalClose"></div>';
    result += '<div class="title"><div class="text"></div><div class="download">Export to .csv</div></div>';
    result += '</div>';
    result += '<div class="AIG_ModalBody">';
    result += '</div>';
    //result += '<div class="footer">';
    //result += '<div class="close AIG_ModalClose">Close</div>';
    //result += '</div>';
    result += '</div>';
    result += '</div>';

    return result;
}

//Check If QV Object Is Table - Change ColSpan
var AIG_Interval = null;
var curObj = null;
function CheckIfTable(app, ObjID, DIV) {
    app.getObject(ObjID).then(function (QKObject) {
        if (QKObject.genericType == "table") {
            AIG_Interval = setInterval(function () { UpdateColSpan($(DIV)) }, 10);
        }
    });

    //Update Column Span
    function UpdateColSpan(parentDIV) {
        //Style Table Object
        if (parentDIV.find('.qv-st-header-cell-dimension').attr('colspan') == 1) {
            parentDIV.find('.qv-st-header-cell-dimension').attr('colspan', '2').addClass('AIG_SPAN');

            //On Header Hover
            parentDIV.find('.qv-st-header-cell-dimension').hover(
                function () {
                    //HOVER
                    //Remove Show Class / ColSpan From All Headers
                    $(this).parent().find('.qv-st-header-cell-dimension').attr('colspan', '2');
                    $(this).parent().find('.qv-st-header-cell-search').removeClass('AIG_ShowCell');

                    //Show Search Icon For Hover Over Cell Only
                    $(this).attr('colspan', '1');
                    $(this).next('th').addClass('AIG_ShowCell');

                    curObj = $(this).find('span').attr('title');

                }, function () {
                    //LEAVE

                    if ($('.qv-st-header-cell-dimension:hover').length == 0 && $('.qv-st-header-cell-search:hover').length == 0) {
                        //Remove Show Class / ColSpan From All Headers
                        $('.AIG_SPAN').attr('colspan', '2').removeClass('.AIG_SPAN');
                        $('.AIG_ShowCell').removeClass('AIG_ShowCell');
                    }                  
                }
            );
            
            clearInterval(AIG_Interval);
        }
    }

   
}