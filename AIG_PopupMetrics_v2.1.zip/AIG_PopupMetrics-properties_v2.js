//-----------------------
// AIG TABS
//-----------------------

//Main Navigation Parameter
var AIG_Objects = {
    ref: "UserParameters.AIG_Objects",
    label: "JASON List of object ID's",
    type: "string",
  	expression: "optional"
};

//Centre Align Text
var AIG_CentreAlign = {
    type: "boolean",
    component: "switch",
    label: "Centre align Tile Text?",
    ref: "UserParameters.AIG_CentreText",
    options: [{
        value: false,
        label: "Left Align"
    }, {
        value: true,
        label: "Centre Align"
    }],
    defaultValue: false
};

//Max Tile Width
var AIG_MaxTileWidth = {
    type: "integer",
    label: "Max Tile Width (-1 for no limit)",
    ref: "UserParameters.AIG_MaxTileWidth",
    defaultValue: "-1",
    min: "-1",
    max: "400"
}

//Max Tile Width
var AIG_Apply = {
    label:"Apply Changes",
    component: "button",
    action: function (data) {
        //add your button action here
        alert("My visualization extension name is '" + data.visualization + "' and have id ");
    }
}


//-----------------------
// ADD TO SETTINGS PANE
//-----------------------

// Appearance section, now re-using the appearance section + injecting our myTextBox component
var appearanceSection = {
    uses: "settings",
    items: {        
        myNewHeader: {
            type: "items",
            label: "AIG Parameters",
            items: {
                AIG_Objects: AIG_Objects,
                AIG_CentreAlign: AIG_CentreAlign,
                AIG_MaxTileWidth: AIG_MaxTileWidth,
                AIG_Apply: AIG_Apply
            }
        }        
	}
};


define( [], function ( ) {
	
	return {
		type: "items",
		component: "accordion",
		items: {
		  	appearance: appearanceSection
		}
	};
 
});