﻿define( ["qlik", "text!./AIG_FilterPane.html", "./Utilities", "css!./css/AIG_FilterPane.css"],
	function ( qlik, template, Utilities ) {

		var app = qlik.currApp(this);

		return {
			template: template,
			support: {
				snapshot: false,
				export: false,
				exportData: false
			},
			initialProperties: {
				filterPaneItems: []
			},
			definition : {
				type : "items",
				component : "accordion",
				items: {
					settings: {
						uses: "settings",
						items: {
							FilterPaneShow: {
								label: "Default View",
								type: "string",
								component: "dropdown",
								ref: "filterPaneShow",
								options: [ 
									{ value: "auto", label: "Auto"},
									{ value: "hidden", label: "Hidden" }, 
									{ value: "visible", label: "Visible" },
									{ value: "always", label: "Always"},
									{ value: "never", label: "Never"}
								],
								defaultValue: "auto"
							},
							InfoText: {
								label: "Info Text",
								type: "string",
								ref: "filterPaneInfo",
								expression: "optional"
							}
						}
					},
					MyList: {
						type: "array",
						ref: "filterPaneItems",
						label: "Filter Pane Items",
						itemTitleRef: "label",
						allowAdd: true,
						allowRemove: true,
						addTranslation: "Add Section",
						items: {
							label: {
								type: "string",
								ref: "label",
								label: "Filter Title",
								expression: "optional"
							},
							itemList: {
								type: "array",
								ref: "itemList",
								allowAdd: true,
								allowRemove: true,
								allowMove: true,
								addTranslation: "Add item",
								items: {
									fieldOrObject: {
										type: "string",
										component: "buttongroup",
										ref: "fieldOrObject",
										options: [
											// { value: "field", label: "Field"},
											{ value: "object", label: "Object"}
										],
										defaultValue: "object"
									},
									object: {
										component: "dropdown",
										type: "string",
										ref: "object",
										show: function(data) { return data.fieldOrObject === "object" },
										options: function(data) { return Utilities.getMasterObjectList() }
									},
									field: {
										component: "dropdown",
										type: "string",
										ref: "field",
										show: function(data) { return data.fieldOrObject === "field" },
										options: function(data) { return Utilities.getFieldList() }
									},
									height: {
										label: "Height",
										type: "integer",
										ref: "height",
										defaultValue: 10,
										expression: "optional",
										show: function(data) { return data.fieldOrObject === "object" },
									}
								}
							},
							alwaysExpanded: {
								label:"Always Expanded?",
								type: "boolean",
								component: "switch",
								ref: "alwaysExpanded",
								defaultValue: false,
								options: [ { value: true, label: "On" }, { value: false, label: "Off" } ],
							},
							show: {
								label: "Show/Hide Expression",
								type: "string",
								expression: "always",
								ref: "show"
							}
						}
					},
					about: {
						label: "About",
						component: {
							template: '<div style="width:95%;padding-left:10px;"><p>Extension: <b>{{extensionName}}</b></p><p>Version: <b>{{extensionVersion}}</b></p><p>Author: <b>{{extensionAuthor}}</b></p><p>Released: <b>{{extensionReleased}}</b></p></div>',
							controller: ["$scope", function($scope) {
								$scope.extensionName = "AIG Filter Pane";
								$scope.extensionVersion = "2.0";
								$scope.extensionAuthor = "Graham Fletcher";
								$scope.extensionReleased = "21/03/2018";
							}]
						}
					}
				}
			},

			resize: function() {

			},

			paint: function ($element, layout) {

				//Move filter pane up to qvt-sheet-container
				if (($('.qvt-sheet-container').children('.FilterPane').length > 0 && $('[qv-extension="AIG_FilterPane"] > .FilterPane').length) > 0) {
					$('.qvt-sheet-container > .FilterPane').replaceWith($('[qv-extension="AIG_FilterPane"] > .FilterPane'));
				} else {
					$('.qvt-sheet-container').prepend($('[qv-extension="AIG_FilterPane"] > .FilterPane'));
					$('.qvt-sheet-container').css({
						"flex-direction": "row",
					});
				}

				// Add alwaysExpanded objects into filter pane
				var filterPaneItemObjectList = $('[itemtype="object"]');

				for (var i=0; i < filterPaneItemObjectList.length; i++) {
					if (filterPaneItemObjectList[i].attributes.itemobject.value) {
						if (filterPaneItemObjectList[i].children.length === 0) {
							qlik.currApp().getObject(filterPaneItemObjectList[i], filterPaneItemObjectList[i].attributes.itemobject.value)
						}
					}
				}

				return qlik.Promise.resolve();
			},
			controller: ["$scope", function ($scope) {

				// Use cookies to keep filterPaneShow consistent between sheets
				var filterPaneShow = readCookie('AIG_FilterPaneShow');

				if (filterPaneShow == null) {
					if ($scope.layout.filterPaneShow === 'auto') {
						createCookie('AIG_FilterPaneShow', 'visible');
						$scope.filterPaneShow = 'visible';
					} else {
						createCookie('AIG_FilterPaneShow', $scope.layout.filterPaneShow);
						$scope.filterPaneShow = $scope.layout.filterPaneShow;
					}
				} else {
					if ($scope.layout.filterPaneShow === 'auto') {
						$scope.filterPaneShow = readCookie('AIG_FilterPaneShow');
					} else {
						$scope.filterPaneShow = $scope.layout.filterPaneShow;
					}
				}

				$scope.filterPaneShowAll = false;
				$scope.filterPaneItems = $scope.layout.filterPaneItems;

				$scope.allFilterPaneItemsAlwaysExpanded = $scope.filterPaneItems.every(function(item) {return item.alwaysExpanded});

				$scope.getFieldSelections = function(field) {
					var fieldSelectionState = app.selectionState().selections.filter(function(selection) {
						return selection.fieldName === field
					}) 
					//length > 25 then count of total
					var fieldSelectionText;
					if (fieldSelectionState.length) {
						if (fieldSelectionState[0].qSelected.length > 25) {
							fieldSelectionText = fieldSelectionState[0].selectedCount + ' of ' + fieldSelectionState[0].totalCount;
						} else {
							fieldSelectionText = fieldSelectionState[0].qSelected
						}
					}
					return fieldSelectionState.length ? '<span class="FilterPaneFieldSelections">' + fieldSelectionText + '</span>' : '<span style="color:#cacadc;font-style:italic;font-family:Arial;font-size:13px;">Search</span>'
				}

				$scope.checkFieldOnShow = function(field) {
					if (!field) return false;
					var element = document.querySelector('[itemfield="' + field + '"]');
					return !element ? false : element.classList.contains('fieldShow');
				}

				// $scope.onFilterPaneItemFieldClick = function(item, e) {
					
				// 	var element = document.querySelector('[itemfield="' + item.field + '"]');
				// 	var qvEvent = document.createEvent('Event')
				// 	qvEvent.initEvent('qv-activate', true, true)

				// 	if (element.classList.contains('fieldShow')) {
				// 		if (e.target.classList.contains('lui-icon--search')) {
				// 			setTimeout(function() {
				// 				return element.querySelector('.qv-object-search').dispatchEvent(qvEvent);
				// 			}, 0)
				// 		} else {
				// 			element.classList.remove('fieldShow')
				// 			element.removeChild(element.children[0])
				// 		}
				// 	} else {
				// 		element.classList.add('fieldShow')
				// 		qlik.currApp().visualization.create(
				// 			'listbox', [item.field], {"showTitles": false}
				// 		).then(function(vis){
				// 			vis.show(element);
				// 			return Promise.resolve();
				// 		}).then(function() {
				// 			setTimeout(function() {
				// 				element.querySelector('.qv-object-search').dispatchEvent(qvEvent)
				// 			}, 5)
				// 			return Promise.resolve();
				// 		})
				// 		// Attempting to add event handler onto confirm selection button to collapse the listbox
				// 		// .then(function() {
				// 		// 	setTimeout(function() {
				// 		// 		document.querySelector('.sel-toolbar-btn.sel-toolbar-confirm').onclick = function() {
				// 		// 			console.log(element)
				// 		// 			element.classList.remove('fieldShow')
				// 		// 			element.removeChild(element.children[0])
				// 		// 		}
				// 		// 	}, 150)
				// 		// })
				// 	}
				// }

				$scope.onFilterPaneItemClick = function(index) {
					// Do nothing if filter pane is always expanded
					if ($scope.filterPaneItems[index].alwaysExpanded) return;

					$scope.filterPaneItems[index].expanded = !$scope.filterPaneItems[index].expanded || $scope.filterPaneItems[index].alwaysExpanded;

					addObjectsIntoDivs(index)
	
					var allExpandedCheck = $scope.filterPaneItems.every(function(item) {return item.expanded || item.alwaysExpanded});
					if (allExpandedCheck) {
						$scope.filterPaneShowAll = false;
						$scope.onFilterPaneShowAllClick();
					}

					var allCollapsedCheck = $scope.filterPaneItems.every(function(item) {return !item.expanded || !item.alwaysExpanded});
					if (allCollapsedCheck) {
						$scope.filterPaneShowAll = true;
					}
				}

				$scope.onFilterPaneShowAllClick = function() {
					if ($scope.allFilterPaneItemsAlwaysExpanded) return;
					$scope.filterPaneShowAll = !$scope.filterPaneShowAll;
					$scope.filterPaneItems.forEach(function(filterPaneItem, i) {
						filterPaneItem.expanded = $scope.filterPaneShowAll
						addObjectsIntoDivs(i)
					})
				}
				
				$scope.onFilterPaneShowClick = function() {
					switch (readCookie('AIG_FilterPaneShow')) {
						case "hidden":
							$scope.filterPaneShow = "visible";
							createCookie('AIG_FilterPaneShow', 'visible');
							qlik.resize();
							break;
						case "visible":
							$scope.filterPaneShow = "hidden";
							createCookie('AIG_FilterPaneShow', 'hidden');
							qlik.resize();
							break;
					}
				}

			}]
		};

		function addObjectsIntoDivs(index) {
			// Add objects into clicked filter pane section
			var filterPaneItemsChildren = document.querySelectorAll('.FilterPaneItem')[index].children
			for (var i=0; i < filterPaneItemsChildren.length; i++) {
				var objects = filterPaneItemsChildren[i].querySelectorAll('.object');
				for (var j=0; j < objects.length; j++) {
					qlik.currApp().getObject(objects[j].children[1], objects[j].children[1].attributes['itemobject'].value)
				}
			}
		}

		function createCookie(name,value,days) {
			if (days) {
				var date = new Date();
				date.setTime(date.getTime()+(days*24*60*60*1000));
				var expires = "; expires="+date.toGMTString();
			}
			else var expires = "";
			document.cookie = name+"="+value+expires+"; path=/";
		}
		
		function readCookie(name) {
			var nameEQ = name + "=";
			var ca = document.cookie.split(';');
			for(var i=0;i < ca.length;i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1,c.length);
				if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
			}
			return null;
		}
		
		function eraseCookie(name) {
			createCookie(name,"",-1);
		}

	} );