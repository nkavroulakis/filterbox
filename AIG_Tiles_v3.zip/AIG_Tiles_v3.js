define( ["qlik", 'ng!$q', "text!./AIG_Tiles_v3.html", "./Utilities", "css!./css/AIG_Tiles_v3.css"],
	function ( qlik, $q, template, Utilities ) {

		var app = qlik.currApp(this);

		// move this to Utilities at some point...
		var aigGetObject = function(object, noInteraction, noSelections) {
			var selector = 'div[aigobject="' + object + '"]';
			setTimeout(function() {
				app.getObject(document.querySelector(selector), object, {"noSelections": noInteraction || noSelections, "noInteraction": noInteraction})
			})
		}

		var columnItems = {
				width: {
					type: "string",
					expression: "optional",
					ref: "width",
					label: "Width for Column as %"
				},
				rows: {
					type: "array",
					ref: "rows",
					label: "Rows for Column",
					itemTitleRef: function(data, i) {
						return "Row " + (i+1)
					},
					allowAdd: true,
					allowRemove: true,
					addTranslation: "Add Row",
					items: {
						height: {
							type: "string",
							expression: "optional",
							label: "Height for Row as %",
							ref: "height"
						},
						exprOrObject: {
							component: "buttongroup",
							label: "Choose to supply Object or Expression",
							ref: "exprOrObject",
							options: [
								{value: "expr", label: "Expression"},
								{value: "obj", label: "Object"}
							],
							defaultValue: "expr"
						},
						object: {
							component: "dropdown",
							type: "string",
							ref: "object",
							label: "Choose an object from Master Items with tag KPI_Tile",
							options: function(data) { return Utilities.getMasterObjectListByTag('KPI_Tile') },
							show: function(data) { return data.exprOrObject === 'obj'},
							change: function(data) { aigGetObject(data.object, data.objectDisableInteraction, data.objectDisableSelection) }
						},
						objectDisableInteraction: {
							type: "boolean",
							ref: "objectDisableInteraction",
							label: "Disable Interactions?",
							defaultValue: false,
							show: function(data) { return data.exprOrObject === 'obj'},
							change: function(data) { aigGetObject(data.object, data.objectDisableInteraction, data.objectDisableSelection) }
						},
						objectDisableSelection: {
							type: "boolean",
							ref: "objectDisableSelection",
							label: "Disable Selections Only?",
							defaultValue: false,
							show: function(data) { return data.exprOrObject === 'obj' && !data.objectDisableInteraction},
							change: function(data) { aigGetObject(data.object, data.objectDisableInteraction, data.objectDisableSelection) }
						},
						// objectByIdOrName: {
						// 	component: "buttongroup",
						// 	label: "Find by ID or Name",
						// 	ref: "objectByIdOrName",
						// 	options: [
						// 		{value: "id", label: "ID"},
						// 		{value: "name", label: "Name"}
						// 	],
						// 	defaultValue: "name",
						// 	show: function(data) { return data.object === 'custom' }
						// },
						// objectExpression: {
						// 	type: "string",
						// 	ref: "objectExpression",
						// 	expression: "optional",
						// 	label: function(data) { return "Enter Object " + data.objectByIdOrName },
						// 	show: function(data) { return data.object === 'custom' }
						// },
						expression: {
							type: "string",
							ref: "expression",
							expression: "optional",
							label: "Enter an expression or text to display",
							show: function(data) { return data.exprOrObject === 'expr'}
						},
						colorType: {
							type: "string",
							ref: "colorType",
							component: "buttongroup",
							options: [
								{value: "expr", label: "Expression"},
								{value: "picker", label: "Picker"}
							],
							defaultValue: "expr",
							show: function(data) { return data.exprOrObject === 'expr'}
						},
						color: {
							type: "object",
							component: "color-picker",
							ref: "color",
							label: "Choose a font colour",
							defaultValue: {
								index: 3,
								color: "#4477aa"
							},
							show: function(data) { return data.exprOrObject === 'expr' && data.colorType === "picker" }
						},
						colorExpr: {
							type: "string",
							ref: "colorExpr",
							label: "Enter RGB or HEX colour",
							expression: "optional",
							show: function(data) { return data.exprOrObject === 'expr' && data.colorType === "expr" }
						},
						size: {
							type: "string",
							ref: "size",
							component: "dropdown",
							label: "Choose a font size",
							options: [
								{value: "x-small", label: "Extra Small"},
								{value: "small", label: "Small"},
								{value: "medium", label: "Medium"},
								{value: "large", label: "Large"},
								{value: "x-large", label: "Extra Large"}
							],
							defaultValue: "medium",
							show: function(data) { return data.exprOrObject === 'expr'}
						},
						font: {
							type: "string",
							ref: "font",
							component: "dropdown",
							label: "Choose a font",
							options: [
								{value: "Futura PT", label: "Futura PT"},
								{value: "Arial", label: "Arial"},
								{value: "QlikView Sans", label: "QlikView Sans"}
							],
							defaultValue: "Futura PT",
							show: function(data) { return data.exprOrObject === 'expr'}
						},
						alignment: {
							type: "string",
							ref: "alignment",
							component: "dropdown",
							label: "Text Align (horizontal)",
							options: [
								{value: "flex-start", label: "left"},
								{value: "center", label: "center"},
								{value: "flex-end", label: "right"}
							],
							defaultValue: "center"
						},
						vertAlign: {
							type: "string",
							ref: "vertAlign",
							component: "dropdown",
							label: "Text Align (vertical)",
							options: [
								{value: "flex-start", label: "top"},
								{value: "center", label: "middle"},
								{value: "flex-end", label: "bottom"}
							],
							defaultValue: "center"
						}
					}
				}
			}

		return {
			template: template,
			support: {
				snapshot: false,
				export: false,
				exportData: false
			},
			initialProperties: {
				AIG_TileList: []
			},
			definition : {
				type : "items",
				component : "accordion",
				items: {
					settings: {
						uses: "settings",
						items: {
							AIG_OverallTileSettings: {
								label: "Overall Tile Settings",
								ref: "AIG_OverallTileSettings",
								type: "items",
								items: {
									AIG_DefaultActiveTile: {
										type: "integer",
										label: "Default active Tile; 0 is none",
										ref: "AIG_DefaultActiveTile",
										defaultValue: 0,
										min: 0
									},
									AIG_TileBgColor: {
										type: "object",
										component: "color-picker",
										ref: "AIG_TileBgColor",
										label: "Background behind Tiles",
										defaultValue: {
											index: 10,
											color: "#ffffff"
										}
									},
									AIG_TileDefaultColor: {
										type: "object",
										component: "color-picker",
										ref: "AIG_TileDefaultColor",
										label: "Default Tile colour",
										defaultValue: {
											index: 10,
											color: "#ffffff"
										}
									},
									AIG_TileDefaultMargin: {
										type: "string",
										ref: "AIG_TileDefaultMargin",
										label: "Default Tile Margin (enter in CSS syntax)",
										defaultValue: 0
									},
									AIG_TileWrap: {
										type: "boolean",
										ref: "AIG_TileWrap",
										label: "Select to allow Tiles to wrap",
										defaultValue: false
									},
									AIG_CustomSizing: {
										type: "boolean",
										ref: "AIG_CustomSizing",
										label: "Select custom sizing for Tiles?",
										defaultValue: false
									},
									AIG_TileCustomWidth: {
										type: "string",
										ref: "AIG_TileCustomWidth",
										label: "width",
										expression: "optional",
										show: function(data) { return data.AIG_CustomSizing}
									},
									AIG_TileCustomMinWidth: {
										type: "string",
										ref: "AIG_TileCustomMinWidth",
										label: "min-width",
										expression: "optional",
										show: function(data) { return data.AIG_CustomSizing}
									},
									AIG_TileCustomMaxWidth: {
										type: "string",
										ref: "AIG_TileCustomMaxWidth",
										label: "max-width",
										expression: "optional",
										show: function(data) { return data.AIG_CustomSizing}
									},
									AIG_TileCustomHeight: {
										type: "string",
										ref: "AIG_TileCustomHeight",
										label: "height",
										expression: "optional",
										show: function(data) { return data.AIG_CustomSizing}
									},
									AIG_TileCustomMinHeight: {
										type: "string",
										ref: "AIG_TileCustomMinHeight",
										label: "min-height",
										expression: "optional",
										show: function(data) { return data.AIG_CustomSizing}
									},
									AIG_TileCustomMaxHeight: {
										type: "string",
										ref: "AIG_TileCustomMaxHeight",
										label: "max-height",
										expression: "optional",
										show: function(data) { return data.AIG_CustomSizing}
									},
									AIG_RowTitleColor: {
										type: "object",
										component: "color-picker",
										ref: "AIG_RowTitleColor",
										label: "Row Title font colour",
										defaultValue: {
											index: 3,
											color: "#4477aa"
										},
									},
									AIG_RowTitleSize: {
										type: "string",
										ref: "AIG_RowTitleSize",
										component: "dropdown",
										label: "Row Title font size",
										options: [
											{value: "x-small", label: "Extra Small"},
											{value: "small", label: "Small"},
											{value: "medium", label: "Medium"},
											{value: "large", label: "Large"},
											{value: "x-large", label: "Extra Large"}
										],
										defaultValue: "medium",
									},
									AIG_RowTitleFont: {
										type: "string",
										ref: "AIG_RowTitleFont",
										component: "dropdown",
										label: "Row Title font",
										options: [
											{value: "Futura PT", label: "Futura PT"},
											{value: "Arial", label: "Arial"},
											{value: "QlikView Sans", label: "QlikView Sans"}
										],
										defaultValue: "Futura PT",
									},
									AIG_RowTitleAlignment: {
										type: "string",
										ref: "AIG_RowTitleAlignment",
										component: "dropdown",
										label: "Row Title Text Align",
										options: [
											{value: "flex-start", label: "left"},
											{value: "center", label: "center"},
											{value: "flex-end", label: "right"}
										],
										defaultValue: "flex-start"
									},
									AIG_PopoutPerRow: {
										type: "boolean",
										ref: "AIG_PopoutPerRow",
										label: "Select to have popouts on each row",
										defaultValue: false
									}
								}
							}
						}
					},
					AIG_TileList: {
						type: "array",
						ref: "AIG_TileList",
						label: "KPI Tile List",
						itemTitleRef: "name",
						allowAdd: true,
						allowRemove: true,
						addTranslation: "Add KPI Tile",
						items: {
							name: {
								type: "string",
								label: "Name for the Tile",
								ref: "name"
							},
							showTitle: {
								type: "boolean",
								label: "Show name as title?",
								ref: "showTitle",
								defaultValue: false
							},
							showTile: {
								type: "string",
								label: "Return 0 to hide Tile",
								ref: "showTile",
								expression: "optional"
							},
							showBorder: {
								type: "boolean",
								ref: "showBorder",
								label: "Select to show border",
								defaultValue: true
							},
							color: {
								type: "object",
								component: "color-picker",
								ref: "color",
								label: "Choose a font colour",
								defaultValue: {
									index: 3,
									color: "#4477aa"
								},
								show: function(data) { return data.showTitle }
							},
							size: {
								type: "string",
								ref: "size",
								component: "dropdown",
								label: "Choose a font size",
								options: [
									{value: "x-small", label: "Extra Small"},
									{value: "small", label: "Small"},
									{value: "medium", label: "Medium"},
									{value: "large", label: "Large"},
									{value: "x-large", label: "Extra Large"}
								],
								defaultValue: "medium",
								show: function(data) { return data.showTitle }
							},
							font: {
								type: "string",
								ref: "font",
								component: "dropdown",
								label: "Choose a font",
								options: [
									{value: "Futura PT", label: "Futura PT"},
									{value: "Arial", label: "Arial"},
									{value: "QlikView Sans", label: "QlikView Sans"}
								],
								defaultValue: "Futura PT",
								show: function(data) { return data.showTitle }
							},
							alignment: {
								type: "string",
								ref: "alignment",
								component: "dropdown",
								label: "Text Align",
								options: [
									{value: "flex-start", label: "left"},
									{value: "center", label: "center"},
									{value: "flex-end", label: "right"}
								],
								defaultValue: "flex-start"
							},
							rowNumber: {
								type: "integer",
								ref: "rowNumber",
								label: "Enter row number",
								defaultValue: 1,
								min: 1
							},
							showRowTitle: {
								type: "boolean",
								ref: "showRowTitle",
								label: "Select to show a title above Tile",
								defaultValue: false
							},
							rowTitle: {
								type: "string",
								ref: "rowTitle",
								label: "Enter row title",
								expression: "optional",
								show: function(data) {
									return data.showRowTitle
								}
							},
							actions: {
								type: "array",
								ref: "actions",
								label: "Tile Actions",
								itemTitleRef: function(data) {
									return data.actionType;
								},
								allowAdd: true,
								allowRemove: true,
								addTranslation: "Add Action",
								items: {
									actionType: {
										type: "string",
										component: "dropdown",
										ref: "actionType",
										label: "Select an action",
										options: [
											{ value: "setVariable", label: "Set variable" },
											{ value: "selectInField", label: "Select in field"},
											{ value: "clearField", label: "Clear a field"},
											{ value: "clearAllFields", label: "Clear ALL fields"},
											{ value: "gotoSheet", label: "Go to sheet"},
											{ value: "gotoUrl", label: "Go to URL"},
											{ value: "lockField", label: "Lock a field for selection" },
											{ value: "unlockField", label: "Unlock a field for selection" },
											{ value: "clickTile", label: "Click a Tile" }
										]
									},
									setVariableName: {
										type: "string",
										ref: "setVariableName",
										label: "Enter variable name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									setVariableValue: {
										type: "string",
										ref: "setVariableValue",
										label: "Enter variable value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									selectInFieldName: {
										type: "string",
										ref: "selectInFieldName",
										label: "Enter field name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldValue: {
										type: "string",
										ref: "selectInFieldValue",
										label: "Enter field value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldToggleSelect: {
										type: "boolean",
										label: "Toggle select?",
										ref: "selectInFieldToggleSelect",
										defaultValue: true,
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									clearFieldName: {
										type: "string",
										ref: "clearFieldName",
										label: "Enter field name to clear",
										expression: "optional",
										show: function(data) {
											return data.actionType === "clearField";
										}
									},
									gotoSheetOption: {
										type: "string",
										ref: "gotoSheetOption",
										component: "buttongroup",
										options: [
											{ value: "list", label: "List", tooltip: "Choose the sheet from a list" },
											{ value: "expr", label: "Expr", tooltip: "Define sheet using an expression" }
										],
										defaultValue: "list",
										show: function(data) {
											return data.actionType === "gotoSheet";
										}
									},
									gotoSheetName: {
										type: "string",
										ref: "gotoSheetName",
										label: "Enter sheet name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "expr";
										}
									},
									gotoSheetId: {
										type: "string",
										ref: "gotoSheetId",
										label: "Select a sheet",
										component: "dropdown",
										options: Utilities.getSheetList(),
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "list";
										}
									},
									gotoUrlName: {
										type: "string",
										ref: "gotoUrlName",
										label: "Enter URL",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoUrl";
										}
									},
									lockFieldName: {
										type: "string",
										ref: "lockFieldName",
										label: "Enter field name to lock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "lockField";
										}
									},
									unlockFieldName: {
										type: "string",
										ref: "unlockFieldName",
										label: "Enter field name to unlock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "unlockField";
										}
									},
									tileNameToClick: {
										type: "string",
										ref: "tileNameToClick",
										label: "Enter Tile name to click",
										expression: "optional",
										show: function(data) {
											return data.actionType === "clickTile";
										}
									}
								}
							},
							columns: {
								type: "array",
								ref: "columns",
								label: "Columns for Tile",
								itemTitleRef: function(data, i) {
									return "Column " + (i+1)
								},
								allowAdd: true,
								allowRemove: true,
								addTranslation: "Add Column",
								items: columnItems
							}
							,
							showPopoutSheet: {
								type: "boolean",
								ref: "showPopoutSheet",
								label: "Show popout?",
								defaultValue: false
							},
							popoutStyle: {
								type: "string",
								component: "buttongroup",
								ref: "popoutStyle",
								options: [
									// {value: "sheet", label: "Other Sheet"}, //currently removed due to loading speed
									{value: "none", label: "This Sheet"},
									{value: "custom", label: "Custom"}
								],
								defaultValue: "none",
								show: function(data) {
									return data.showPopoutSheet
								}
							},
							popoutCustomLayout: {
								type: "array",
								ref: "popoutColumns",
								label: "Columns for Popout",
								itemTitleRef: function(data, i) {
									return "Column " + (i+1)
								},
								allowAdd: true,
								allowRemove: true,
								addTranslation: "Add Column",
								items: columnItems,
								show: function(data) {
									return data.showPopoutSheet && data.popoutStyle === "custom"
								}
							},
							popoutCustomStyle: {
								type: "string",
								ref: "popoutCustomStyle",
								label: "Popout style",
								component: "dropdown",
								options: [
									{value: "inline", label: "Inline"},
									{value: "overlay", label: "Overlay"},
								],
								defaultValue: "inline",
								show: function(data) {
									return data.showPopoutSheet && data.popoutStyle === "custom"
								}
							},
							popoutCustomHeight: {
								type: "string",
								ref: "popoutCustomHeight",
								label: "Enter popout height",
								expression: "optional",
								show: function(data) {
									return data.showPopoutSheet && data.popoutStyle === "custom"
								},
								defaultValue: "250px",
							},
							// popoutCustomWidth: {
							// 	type: "string",
							// 	ref: "popoutCustomWidth",
							// 	label: "Enter popout width",
							// 	expression: "optional",
							// 	show: function(data) {
							// 		return data.showPopoutSheet && data.popoutStyle === "custom"
							// 	}
							// },
							popoutSheet: {
								type: "string",
								component: "dropdown",
								ref: "popoutSheet",
								label: "Select sheet to show in popout",
								options: function(data) {
									return Utilities.getSheetList().then(function(sheets) {
										return sheets
										// .filter(function(sheet) {
											//Return only sheets with $POPOUT prefix
											// return !sheet.label.indexOf('$POPOUT');
										// })
									});
								},
								show: function(data) {
									return data.showPopoutSheet && data.popoutStyle === "sheet"
								}
							}
						}
					},
					about: {
						label: "About",
						ref: "AIG_About",
						component: {
							template: '<div style="width:95%;padding-left:10px;"><p>Extension: <b>{{extensionName}}</b></p><p>Version: <b>{{extensionVersion}}</b></p><p>Author: <b>{{extensionAuthor}}</b></p><p>Released: <b>{{extensionReleased}}</b></p></div>',
							controller: ["$scope", function($scope) {
								$scope.extensionName = "AIG Tiles";
								$scope.extensionVersion = "3.3.3";
								$scope.extensionAuthor = "Graham Fletcher";
								$scope.extensionReleased = "06/12/2018";
							}]
						}
					}
                }
			},

			paint: function ($element, layout) {
				// console.log(layout)

				if (($('#grid').children('.AIG-tile-popout').length > 0 && $('[qv-extension="AIG_Tiles_v3"] > .AIG-tile-popout').length) > 0) {
					$('#grid > .AIG-tile-popout').replaceWith($('[qv-extension="AIG_Tiles_v3"] > .AIG-tile-popout'));
					// $('#grid > .AIG-tile-popout-cover').replaceWith($('[qv-extension="AIG_Tiles_v3"] > .AIG-tile-popout-cover'));
				} else {
					$('#grid').append($('[qv-extension="AIG_Tiles_v3"] > .AIG-tile-popout'));
					// $('#grid').append($('[qv-extension="AIG_Tiles_v3"] > .AIG-tile-popout-cover'));
				}

				return qlik.Promise.resolve();
			},
			controller: ['$scope', '$sce', '$timeout', '$element', function ( $scope, $sce, $timeout, $element ) {

				$scope.showPopoutSheet = function(tileRow) {
					return $scope.popoutTileNumber === -1 ? false : $scope.layout.AIG_TileList[$scope.popoutTileNumber ].showPopoutSheet
				}

				$scope.getTileRowCount = function(tiles) {
					var unique = {};
					var distinct = [];
					for( var i in tiles ){
						if( typeof(unique[tiles[i].rowNumber]) == "undefined"){
							distinct.push(tiles[i].rowNumber);
						}
						unique[tiles[i].rowNumber] = 0;
					}
					return distinct.sort()
				}

				$scope.showRowTitle = function(row) {
					return $scope.layout.AIG_TileList.filter(function(tile) {
						return tile.rowNumber === row && tile.showRowTitle && tile.showTile !== '0'
					}).length > 0
				}

				$scope.getRowTitle = function(row) {
					return $scope.layout.AIG_TileList.filter(function(tile) {
						return tile.rowNumber === row && tile.showRowTitle && tile.showTile !== '0'
					})[0].rowTitle
				}

				$scope.getRowObjectID = function(row) {
					var objectID;
					if (row.object !== 'custom') {
						objectID = row.object
					} else {
						if (row.objectByIdOrName === 'id') {
							objectID = row.objectExpression
						} else {
							return Utilities.getMasterObjectIdByName(row.objectExpression)
						}
					} 
					return objectID
					
					//Utilities.getMasterObjectIdByName(row.objectExpression).then(function(objectId) {return objectId})
				}

				// $scope.getPopoutColumns = function(tileRow) {
				// 	if (document.querySelector('.selected-tile')) {
				// 		var rowTileList = $scope.layout.AIG_TileList.filter(function(tile) {
				// 			return tile.rowNumber === tileRow
				// 		})
				// 		return rowTileList[document.querySelector('.selected-tile').attributes.tileindex.value].popoutColumns
				// 	} else {
				// 		return []
				// 	}
				// }
				
				$scope.aigGetObject = aigGetObject;
				$scope.appId = app.id;
				// $scope.getMasterObjectIdByName = Utilities.getMasterObjectIdByName;

				$scope.inEditMode = function() {
					return qlik.navigation.getMode() === 'edit'
				}

				$scope.loadedUrl = window.location.href;

				$scope.sameSheet = function() {
					return $scope.loadedUrl === window.location.href;
				}

				$scope.getDefaultStyle = function(elementType) {
					var bodyClientRect = document.body.getBoundingClientRect()
					var gridClientRect = document.querySelector('#grid').getBoundingClientRect()

					var style = {};

					if ($scope.layout.AIG_DefaultActiveTile > 0) {
						var tiles = $element.children('.AIG-tile'), top;
						for (var i=0; i < tiles.length; i++) {
							if (i+1 === $scope.layout.AIG_DefaultActiveTile) {
								var tileClientRect = tiles[i].getBoundingClientRect()
								switch(elementType) {
									case 'popout':
										top = tileClientRect.bottom - (bodyClientRect.height - gridClientRect.height) + 17
										style.top = top + "px"
										style.height = gridClientRect.height - top + "px"
										break;
									case 'popout-cover':
										style.top = tileClientRect.bottom - (bodyClientRect.height - gridClientRect.height) + "px"
										style.height = 18 + "px"
										style.left = tileClientRect.left - (bodyClientRect.width - gridClientRect.width) + 5 + "px"
										style.width = tileClientRect.width + "px"
										break;
								}
							}
						}
						style.display = 'flex'
					} else {
						style.display = 'none'
						style.top = "100vh"
					}

					return style
				}

				$scope.popoutTileNumber = $scope.layout.AIG_DefaultActiveTile > 0 ? $scope.layout.AIG_DefaultActiveTile : -1;
				$scope.selectedTile = $scope.layout.AIG_DefaultActiveTile > 0 ? $scope.layout.AIG_TileList[$scope.layout.AIG_DefaultActiveTile] : -1;

				$scope.getPopoutSheetUrl = function(sheetId) {
					if (qlik.navigation.getMode() === 'edit') return;

					if ($scope.popoutSheetId === sheetId) return;

					$scope.popoutSheetId = sheetId;
					var sheetUrl =  '/single/?appid=' + $scope.appId + '&sheet=' + sheetId;					
					return $sce.trustAsResourceUrl(sheetUrl);
				}

				// This works but adds a new class on every time it's clicked
				var UID = {
					_current: 0,
					getNew: function(){
						this._current++;
						return this._current;
					}
				};
				
				HTMLElement.prototype.pseudoStyle = function(element,prop,value){
					var _this = this;
					var _sheetId = "pseudoStyles";
					var _head = document.head || document.getElementsByTagName('head')[0];
					var _sheet = document.getElementById(_sheetId) || document.createElement('style');
					_sheet.id = _sheetId;
					var className = "pseudoStyle" //+ UID.getNew();
					
					_this.className +=  " "+className; 
					
					_sheet.innerHTML += "\n."+className+":"+element+"{"+prop+":"+value+"}";
					_head.appendChild(_sheet);
					return this;
				};
				

				$scope.togglePopout = function($event, tile, tileRow) {
					/** Do not run actions or show/hide popout when in edit mode */
					if (qlik.navigation.getMode() === 'edit') return;

					/** Run actions for the Tile if they are defined */
					if (tile.actions.length > 0) $scope.runActions(tile.actions);

					/** If the actions on the Tile include to click another Tile, then stop here */
					if (tile.actions.filter(function(action) {return action.actionType === 'clickTile'}).length > 0) return;

					/** Check 14 parents up is not a popout so actions still happen but no popout appears when there is a Tile extension within another Tile popout */
					if ($event.currentTarget.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.classList.contains('AIG-tile-popout-inline')) return;
					
					/** If no actions and no popout then do nothing */
					if (tile.actions.length === 0 && !tile.showPopoutSheet) return;

					var thisTileSelected = $event.currentTarget.classList.contains('selected-tile')
					$scope.selectedTile = tile

					if ($scope.layout.popoutPerRow || $scope.getTileRowCount($scope.layout.AIG_TileList).length === 1) {
						if($event.currentTarget.parentElement.querySelector('.AIG-tile-popout-inline')) $event.currentTarget.parentElement.querySelector('.AIG-tile-popout-inline').classList.remove('show-popout')
					} 
					// else {
					// 	var popouts = $element.children('.show-popout')
					// 	for (var i=0; i < popouts.length; i++) {
					// 		popouts[i].classList.remove('show-popout')
					// 	}
					// }

					/**
					 * Remove selected-tile class from all Tiles
					 */
					var selectedTiles = document.querySelectorAll('.selected-tile')
					for (var i=0; i < selectedTiles.length; i++) {
						if ($event.currentTarget !== selectedTiles[i]) {
							selectedTiles[i].classList.remove('selected-tile')
						}
					}
					
					/**
					 * Handle popout showing/hiding and styling for the different options
					 * Also some styling for the Tile depending on selected or not
					 */

					var bodyClientRect = document.body.getBoundingClientRect()
					var gridClientRect = document.querySelector('#grid').getBoundingClientRect()
					var currentTargetClientRect = $event.currentTarget.getBoundingClientRect()
					var popoutInline = $event.currentTarget.parentElement.parentElement.querySelector('#popout-inline-' + (tile.rowNumber - 1))

					if (thisTileSelected && $scope.layout.AIG_DefaultActiveTile === 0) {
						$event.currentTarget.classList.remove('selected-tile')
						if (tile.popoutStyle === 'custom' && (tile.popoutCustomStyle === 'inline' || tile.popoutCustomStyle === 'overlay')) {
							$event.currentTarget.parentElement.parentElement.querySelector('.AIG-tile-popout-inline').classList.remove('show-popout')
							if(!tile.showBorder) {
								$event.currentTarget.parentElement.parentElement.querySelector('.AIG-tile-popout-inline').classList.remove('no-border')
							}
							$event.currentTarget.parentElement.classList.remove('show-popout')
							if(tile.popoutCustomStyle === 'overlay') {
								$event.currentTarget.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style['z-index'] = 1
								$event.currentTarget.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style.overflow = 'hidden'
								popoutInline.style.position = 'unset'
								popoutInline.style['z-index'] = 1
								popoutInline.style['margin-top'] = ""
								$event.currentTarget.parentElement.parentElement.parentElement.parentElement.style.overflow = 'auto'
								document.querySelector('#grid').style.overflow = 'hidden'
							}
						}
					} else if (!thisTileSelected) {

						$event.currentTarget.classList.add('selected-tile')

						if (!tile.showPopoutSheet) {
							$event.currentTarget.parentElement.parentElement.querySelector('.AIG-tile-popout-inline').classList.remove('show-popout')
						} else if (tile.showPopoutSheet) {
							$event.currentTarget.parentElement.classList.add('show-popout')
							if (tile.popoutStyle === 'custom' && (tile.popoutCustomStyle === 'inline' || tile.popoutCustomStyle === 'overlay')) {
								popoutInline.classList.add('show-popout')
								if(!tile.showBorder) {
									popoutInline.classList.add('no-border')
									//Need to add half of the Tile width as this is putting it on the left hand side of the tile at the moment
									var pointerLeft = currentTargetClientRect.left - (bodyClientRect.width - gridClientRect.width)
									pointerLeft = pointerLeft + (currentTargetClientRect.width / 2) - 20
									popoutInline.pseudoStyle("before","left", pointerLeft + "px !important")
								}
								popoutInline.style.height = tile.popoutCustomHeight
								if(tile.popoutCustomStyle === 'overlay') {
									$event.currentTarget.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style['z-index'] = 2
									$event.currentTarget.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.style.overflow = 'unset'
									popoutInline.style.position = 'absolute'
									popoutInline.style['z-index'] = 2
									popoutInline.style['margin-top'] = "10px"
									$event.currentTarget.parentElement.parentElement.parentElement.parentElement.style.overflow = 'unset'
									document.querySelector('#grid').style.overflow = 'auto'
								}
							}
						}

						

						popoutTop = currentTargetClientRect.bottom - (bodyClientRect.height - gridClientRect.height);
						popoutHeight = gridClientRect.height - popoutTop;

						popoutCoverLeft = currentTargetClientRect.left - (bodyClientRect.width - gridClientRect.width);
						
						popoutTop = popoutTop + 17 + "px" //adjust for spacing below tile to popout
						if (tile.popoutStyle === 'custom' && tile.popoutCustomStyle === 'overlay') {
							
						}

					}
					var aigObjectList = $event.currentTarget.parentElement.parentElement.querySelectorAll('#popout-inline-' + (tile.rowNumber - 1) + ' .AIG_TileObject')
					// console.log(aigObjectList)
					for (var i=0; i < aigObjectList.length; i++) {
						if (thisTileSelected) {
							while (aigObjectList[i].lastChild) aigObjectList[i].removeChild(aigObjectList[i].lastChild) 
						} else if (!thisTileSelected) {
							aigGetObject(aigObjectList[i].attributes.aigobject.value)
						}
						
					}
				}

				//Stores the sheet list to scope for use later
				Utilities.getSheetList().then(function(sheets) {
					$scope.sheetList = sheets
					// $scope.sheetList = sheets.filter(function(sheet) {
					// 	return sheet.label.indexOf('$HIDE');
					// })
				});
	
				$scope.currentSheetId = qlik.navigation.getCurrentSheetId().sheetId;
	
				//Function to get the sheet id from given name
				var getSheetId = function(name) {
					return $scope.sheetList.filter(function(sheet) {
						return sheet.label === name;
					})[0].value
				}

				//Set a variable action function
				var setVariable = function(name, value) {
					switch (typeof value) {
						case "string":
							app.variable.setStringValue(name, value);
							break;
						case "number":
							app.variable.setNumValue(name, value);
							break;
					}
				};

				//Select in field action function
				var selectInField = function(name, value, toggle) {
					var valueArray, range = false;
					
					if (value.indexOf(",") !== -1) {
						valueArray = value.split(",").map(function(valueItem) {
							return isNaN(valueItem) ? valueItem : parseInt(valueItem);
						})
					} else {
						range = value.indexOf("<") !== -1 || value.indexOf(">") !== -1 ? true : false;
						valueArray = [isNaN(value) ? value : parseInt(value)]
					}
					if (range) {
						app.field(name).selectMatch(valueArray[0], toggle);
					} else {
						app.field(name).selectValues(valueArray, toggle, true);
					}
				}

				//Clear field action function
				var clearField = function(name) {
					app.field(name).clear();
				}

				//Clear ALL fields action function
				var clearAllFields = function() {
					app.clearAll();
				}

				//Function to go to sheet using the sheet id
				var gotoSheet = function(sheetId) {
					qlik.navigation.gotoSheet(sheetId);
				}

				//Function to lock a field for selections
				var lockField = function(name) {
					app.field(name).lock();
				}

				//Function to unlock a field for selections
				var unlockField = function(name) {
					app.field(name).unlock();
				}

				//Function to click a Tile
				var clickTile = function(tileName) {
					var tileIndex;
					$scope.layout.AIG_TileList.forEach(function(tile, i) { if(tile.name === tileName) tileIndex = i })
					// if(!document.querySelector('.AIG-tile[tileindex="' + tileIndex + '"]').classList.contains('selected-tile')) {
						$timeout(function(){
							angular.element(document.querySelector('.AIG-tile[tileindex="' + tileIndex + '"]')).trigger('click');
							// document.querySelector('.AIG-tile[tileindex="' + tileIndex + '"]').click()
						});
					// }
				}

				// console.log(typeof $scope.layout.sheetActions[1].selectInFieldValue)
				//Run through and execute actions
				$scope.runActions = function(actions) {

					actions.forEach(function(action, i) {
						switch (action.actionType) {
							case "setVariable":
								// $timeout(function() {
									setVariable(action.setVariableName, action.setVariableValue)
								// })
								break;
							case "selectInField":
								// $timeout(function() {
									selectInField(action.selectInFieldName, action.selectInFieldValue.replace(/\"/g, ""), action.selectInFieldToggleSelect); 
								// }, i * 100)
								break;
							case "clearField":
								// $timeout(function() {
									clearField(action.clearFieldName);
								// }, i * 100)
								break;
							case "clearAllFields":
								// $timeout(function() {
									clearAllFields();
								// }, i * 100)
								break;
							case "gotoSheet":
								switch (action.gotoSheetOption) {
									case "expr":
										// $timeout(function() {
											gotoSheet(getSheetId(action.gotoSheetName));
										// }, i * 100)
								break;
									case "list":
										// $timeout(function() {
											gotoSheet(action.gotoSheetId);
										// }, i * 100)
									break;
								}
								break;
							case "gotoUrl":
								var urlPrefix = action.gotoUrlName.indexOf("http") > -1 ? "" : "http://";
								window.open(urlPrefix + action.gotoUrlName);
								break;
							case "lockField":
								// $timeout(function() {
									lockField(action.lockFieldName);
								// }, i * 100)
								break;
							case "unlockField":
								// $timeout(function() {
									unlockField(action.unlockFieldName);
								// }, i * 100)
								break;
							case "clickTile":
								clickTile(action.tileNameToClick);
								break;
						}
					})

				}

            }]
		};
	} );
