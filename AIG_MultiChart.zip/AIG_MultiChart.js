define( ["qlik", "text!./AIG_MultiChart.html", "./Utilities", "css!./css/AIG_MultiChart.css"],
	function ( qlik, template, Utilities ) {

		var app = qlik.currApp(this);

		var aigGetObject = function(object) {
			var selector = 'div[aigobject="' + object + '"]';

			setTimeout(function() {
				app.getObject(document.querySelector(selector), object)
			}, 500)
			
		}

		return {
			template: template,
			support: {
				snapshot: false,
				export: true,
				exportData: false
			},
			initialProperties: {
				AIG_MultiChartList: []
			},
			definition : {
				type : "items",
				component : "accordion",
				items: {
					settings: {
						uses: "settings",
						items: {}
					},
					AIG_MultiChartList: {
						type: "array",
						ref: "AIG_MultiChartList",
						label: "Charts/Objects",
						itemTitleRef: "label",
						allowAdd: true,
						allowRemove: true,
						addTranslation: "Add Chart/Object",
						items: {
							label: {
								type: "string",
								ref: "label",
								label: "Item Label",
								expression: "optional"
							},
							menuSide: {
								type: "string",
								component: "dropdown",
								ref: "menuSide",
								label: "Left or Right menu?",
								options: [
									{value: "left", label: "Left"},
									{value: "right", label: "Right"}
								],
								defaultValue: "left"
							},
							object: {
								component: "dropdown",
								type: "string",
								ref: "object",
								label: "Choose an object from Master Items with tag MultiChart",
								options: function(data) { return Utilities.getMasterObjectListByTag('MultiChart') },
								change: function(data) { aigGetObject(data.object) }
							},
							show: {
								type: "string",
								ref: "show",
								label: "Return 0 to hide option",
								expression: "optional"
							},
							actions: {
								type: "array",
								ref: "actions",
								label: "Actions",
								itemTitleRef: function(data) {
									return data.actionType;
								},
								allowAdd: true,
								allowRemove: true,
								addTranslation: "Add Action",
								items: {
									actionType: {
										type: "string",
										component: "dropdown",
										ref: "actionType",
										label: "Select an action",
										options: [
											{ value: "setVariable", label: "Set variable" },
											{ value: "selectInField", label: "Select in field"},
											{ value: "clearField", label: "Clear a field"},
											{ value: "clearAllFields", label: "Clear ALL fields"},
											{ value: "gotoSheet", label: "Go to sheet"},
											{ value: "gotoUrl", label: "Go to URL"},
											{ value: "lockField", label: "Lock a field for selection" },
											{ value: "unlockField", label: "Unlock a field for selection" }
										]
									},
									setVariableName: {
										type: "string",
										ref: "setVariableName",
										label: "Enter variable name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									setVariableValue: {
										type: "string",
										ref: "setVariableValue",
										label: "Enter variable value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "setVariable";
										}
									},
									selectInFieldName: {
										type: "string",
										ref: "selectInFieldName",
										label: "Enter field name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldValue: {
										type: "string",
										ref: "selectInFieldValue",
										label: "Enter field value",
										expression: "optional",
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									selectInFieldToggleSelect: {
										type: "boolean",
										label: "Toggle select?",
										ref: "selectInFieldToggleSelect",
										defaultValue: true,
										show: function(data) {
											return data.actionType === "selectInField";
										}
									},
									clearFieldName: {
										type: "string",
										ref: "clearFieldName",
										label: "Enter field name to clear",
										expression: "optional",
										show: function(data) {
											return data.actionType === "clearField";
										}
									},
									gotoSheetOption: {
										type: "string",
										ref: "gotoSheetOption",
										component: "buttongroup",
										options: [
											{ value: "list", label: "List", tooltip: "Choose the sheet from a list" },
											{ value: "expr", label: "Expr", tooltip: "Define sheet using an expression" }
										],
										defaultValue: "list",
										show: function(data) {
											return data.actionType === "gotoSheet";
										}
									},
									gotoSheetName: {
										type: "string",
										ref: "gotoSheetName",
										label: "Enter sheet name",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "expr";
										}
									},
									gotoSheetId: {
										type: "string",
										ref: "gotoSheetId",
										label: "Select a sheet",
										component: "dropdown",
										options: Utilities.getSheetList(),
										show: function(data) {
											return data.actionType === "gotoSheet" && data.gotoSheetOption === "list";
										}
									},
									gotoUrlName: {
										type: "string",
										ref: "gotoUrlName",
										label: "Enter URL",
										expression: "optional",
										show: function(data) {
											return data.actionType === "gotoUrl";
										}
									},
									lockFieldName: {
										type: "string",
										ref: "lockFieldName",
										label: "Enter field name to lock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "lockField";
										}
									},
									unlockFieldName: {
										type: "string",
										ref: "unlockFieldName",
										label: "Enter field name to unlock selections",
										expression: "optional",
										show: function(data) {
											return data.actionType === "unlockField";
										}
									}
								}
							}
						}
					},
					about: {
						label: "About",
						component: {
							template: '<div style="width:95%;padding-left:10px;"><p>Extension: <b>{{extensionName}}</b></p><p>Version: <b>{{extensionVersion}}</b></p><p>Author: <b>{{extensionAuthor}}</b></p><p>Released: <b>{{extensionReleased}}</b></p></div>',
							controller: ["$scope", function($scope) {
								$scope.extensionName = "AIG MultiChart";
								$scope.extensionVersion = "0.1";
								$scope.extensionAuthor = "Graham Fletcher";
								$scope.extensionReleased = "10/05/2018";
							}]
						}
					}
                }
			},
			paint: function ($element, layout) {

				return qlik.Promise.resolve();
			},
			controller: ['$scope', function ( $scope ) {
				
				$scope.aigGetObject = aigGetObject;

				$scope.multiChartMenuLeft = function(chartList) {
					return chartList.filter(function(chart) {return chart.menuSide === "left" && chart.show !== '0'})
				}
				$scope.multiChartMenuRight = function(chartList) {
					return chartList.filter(function(chart) {return chart.menuSide === "right" && chart.show !== '0'})
				}

				$scope.currentChart = $scope.layout.AIG_MultiChartList.length > 0 ? $scope.layout.AIG_MultiChartList[0].object : ''

				$scope.changeChart = function(chart) {
					$scope.currentChart = chart.object
					// $scope.aigGetObject(chart.object)
					qlik.resize()
					if(chart.actions && chart.actions.length > 0) $scope.runActions(chart.actions)
				}

				/* vvvvv Functions for actions vvvvv */

				//Stores the sheet list to scope for use later
				Utilities.getSheetList().then(function(sheets) {
					$scope.sheetList = sheets
				});
	
				$scope.currentSheetId = qlik.navigation.getCurrentSheetId().sheetId;
	
				//Function to get the sheet id from given name
				var getSheetId = function(name) {
					return $scope.sheetList.filter(function(sheet) {
						return sheet.label === name;
					})[0].value
				}

				//Set a variable action function
				var setVariable = function(name, value) {
					switch (typeof value) {
						case "string":
							app.variable.setStringValue(name, value);
							break;
						case "number":
							app.variable.setNumValue(name, value);
							break;
					}
				};

				//Select in field action function
				var selectInField = function(name, value, toggle) {
					var valueArray, range = false;
					
					if (value.indexOf(",") !== -1) {
						valueArray = value.split(",").map(function(valueItem) {
							return isNaN(valueItem) ? valueItem : parseInt(valueItem);
						})
					} else {
						range = value.indexOf("<") !== -1 || value.indexOf(">") !== -1 ? true : false;
						valueArray = [isNaN(value) ? value : parseInt(value)]
					}
					if (range) {
						app.field(name).selectMatch(valueArray[0], toggle);
					} else {
						app.field(name).selectValues(valueArray, toggle, true);
					}
				}

				//Clear field action function
				var clearField = function(name) {
					app.field(name).clear();
				}

				//Clear ALL fields action function
				var clearAllFields = function() {
					app.clearAll();
				}

				//Function to go to sheet using the sheet id
				var gotoSheet = function(sheetId) {
					qlik.navigation.gotoSheet(sheetId);
				}

				//Function to lock a field for selections
				var lockField = function(name) {
					app.field(name).lock();
				}

				//Function to unlock a field for selections
				var unlockField = function(name) {
					app.field(name).unlock();
				}

				//Run through and execute actions
				$scope.runActions = function(actions) {

					actions.forEach(function(action, i) {
						switch (action.actionType) {
							case "setVariable":
								setTimeout(function() {
									setVariable(action.setVariableName, action.setVariableValue)
								}, i * 100)
								break;
							case "selectInField":
								setTimeout(function() {
									selectInField(action.selectInFieldName, action.selectInFieldValue.replace(/\"/g, ""), action.selectInFieldToggleSelect); 
								}, i * 100)
								break;
							case "clearField":
								setTimeout(function() {
									clearField(action.clearFieldName);
								}, i * 100)
								break;
							case "clearAllFields":
								setTimeout(function() {
									clearAllFields();
								}, i * 100)
								break;
							case "gotoSheet":
								switch (action.gotoSheetOption) {
									case "expr":
										setTimeout(function() {
											gotoSheet(getSheetId(action.gotoSheetName));
										}, i * 100)
								break;
									case "list":
										setTimeout(function() {
											gotoSheet(action.gotoSheetId);
										}, i * 100)
									break;
								}
								break;
							case "gotoUrl":
								var urlPrefix = action.gotoUrlName.indexOf("http") > -1 ? "" : "http://";
								window.open(urlPrefix + action.gotoUrlName);
								break;
							case "lockField":
								setTimeout(function() {
									lockField(action.lockFieldName);
								}, i * 100)
								break;
							case "unlockField":
								setTimeout(function() {
									unlockField(action.unlockFieldName);
								}, i * 100)
								break;
						}
					})

				}

            }]
		};
	} );
